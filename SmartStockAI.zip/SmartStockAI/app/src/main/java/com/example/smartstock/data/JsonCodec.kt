package com.example.smartstock.data

import org.json.JSONArray
import org.json.JSONObject

object JsonCodec {

    const val SCHEMA_VERSION = 1

    fun encodeItems(items: List<Item>): String {
        val root = JSONObject()
        root.put("schemaVersion", SCHEMA_VERSION)
        val arr = JSONArray()
        items.forEach { arr.put(itemToJson(it)) }
        root.put("items", arr)
        return root.toString()
    }

    fun decodeItems(json: String?): List<Item> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val root = JSONObject(json)
            val arr = root.optJSONArray("items") ?: return emptyList()
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(jsonToItem(obj))
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun encodeSettings(settings: AppSettings): String {
        val root = JSONObject()
        root.put("schemaVersion", SCHEMA_VERSION)
        root.put("settings", settingsToJson(settings))
        return root.toString()
    }

    fun decodeSettings(json: String?): AppSettings {
        if (json.isNullOrBlank()) return AppSettings()
        return try {
            val root = JSONObject(json)
            val obj = root.optJSONObject("settings") ?: root
            jsonToSettings(obj)
        } catch (_: Exception) {
            AppSettings()
        }
    }

    fun encodeHistory(history: List<Txn>): String {
        val root = JSONObject()
        root.put("schemaVersion", SCHEMA_VERSION)
        val arr = JSONArray()
        history.forEach { arr.put(txnToJson(it)) }
        root.put("history", arr)
        return root.toString()
    }

    fun decodeHistory(json: String?): List<Txn> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val root = JSONObject(json)
            val arr = root.optJSONArray("history") ?: return emptyList()
            buildList {
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    add(jsonToTxn(obj))
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Backup JSON: includes items, settings (never API key), and history; excludes photos.
     */
    fun encodeBackup(items: List<Item>, settings: AppSettings, history: List<Txn>): String {
        val root = JSONObject()
        root.put("schemaVersion", SCHEMA_VERSION)
        root.put("exportedAt", System.currentTimeMillis())

        val itemsArr = JSONArray()
        items.forEach { itemsArr.put(itemToJson(it)) }
        root.put("items", itemsArr)

        root.put("settings", settingsToJson(settings))

        val histArr = JSONArray()
        history.forEach { txn ->
            // Exclude photo file references from backup payload
            histArr.put(txnToJson(txn.copy(photoFiles = emptyList())))
        }
        root.put("history", histArr)
        return root.toString(2)
    }

    /**
     * Validates schemaVersion and parses backup payload. Returns null if invalid.
     */
    fun decodeBackup(json: String?): BackupPayload? {
        if (json.isNullOrBlank()) return null
        return try {
            val root = JSONObject(json)
            if (!root.has("schemaVersion")) return null
            val version = root.optInt("schemaVersion", -1)
            if (version < 1 || version > SCHEMA_VERSION) return null
            val itemsArr = root.optJSONArray("items") ?: return null
            val histArr = root.optJSONArray("history") ?: return null
            val settingsObj = root.optJSONObject("settings") ?: return null

            val items = buildList {
                for (i in 0 until itemsArr.length()) {
                    val obj = itemsArr.optJSONObject(i) ?: continue
                    add(jsonToItem(obj))
                }
            }
            val history = buildList {
                for (i in 0 until histArr.length()) {
                    val obj = histArr.optJSONObject(i) ?: continue
                    add(jsonToTxn(obj).copy(photoFiles = emptyList()))
                }
            }
            val settings = jsonToSettings(settingsObj)
            BackupPayload(
                schemaVersion = version,
                exportedAt = root.optLong("exportedAt", System.currentTimeMillis()),
                items = items,
                settings = settings,
                history = history
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun itemToJson(item: Item): JSONObject {
        val obj = JSONObject()
        obj.put("id", item.id)
        obj.put("name", item.name)
        obj.put("unit", item.unit)
        obj.put("qty", item.qty.coerceAtLeast(0))
        obj.put("lowThreshold", item.lowThreshold.coerceAtLeast(0))
        if (item.sellPrice != null) obj.put("sellPrice", item.sellPrice)
        if (item.costPrice != null) obj.put("costPrice", item.costPrice)
        val aliasesArr = JSONArray()
        item.aliases.forEach { aliasesArr.put(it) }
        obj.put("aliases", aliasesArr)
        obj.put("createdAt", item.createdAt)
        return obj
    }

    private fun jsonToItem(obj: JSONObject): Item {
        val aliasesArr = obj.optJSONArray("aliases")
        val aliases = buildList {
            if (aliasesArr != null) {
                for (i in 0 until aliasesArr.length()) {
                    val a = aliasesArr.optString(i, "").trim()
                    if (a.isNotEmpty()) add(a)
                }
            }
        }
        return Item(
            id = obj.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
            name = obj.optString("name", ""),
            unit = obj.optString("unit", Item.DEFAULT_UNIT).ifBlank { Item.DEFAULT_UNIT },
            qty = obj.optInt("qty", 0).coerceAtLeast(0),
            lowThreshold = obj.optInt("lowThreshold", Item.DEFAULT_LOW_THRESHOLD).coerceAtLeast(0),
            sellPrice = if (obj.has("sellPrice") && !obj.isNull("sellPrice")) obj.optDouble("sellPrice") else null,
            costPrice = if (obj.has("costPrice") && !obj.isNull("costPrice")) obj.optDouble("costPrice") else null,
            aliases = aliases,
            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
        )
    }

    private fun settingsToJson(settings: AppSettings): JSONObject {
        val obj = JSONObject()
        obj.put("activeModel", settings.activeModel)
        obj.put("defaultLowThreshold", settings.defaultLowThreshold)
        obj.put("dateStyle", settings.dateStyle.name)
        obj.put("privacyAccepted", settings.privacyAccepted)
        if (settings.cachedAdviceDate != null) obj.put("cachedAdviceDate", settings.cachedAdviceDate)
        val adviceArr = JSONArray()
        settings.cachedAdviceLines.forEach { adviceArr.put(it) }
        obj.put("cachedAdviceLines", adviceArr)
        return obj
    }

    private fun jsonToSettings(obj: JSONObject): AppSettings {
        val dateStyleStr = obj.optString("dateStyle", DateStyle.ETHIOPIAN.name)
        val dateStyle = runCatching { DateStyle.valueOf(dateStyleStr) }.getOrDefault(DateStyle.ETHIOPIAN)
        val adviceArr = obj.optJSONArray("cachedAdviceLines")
        val adviceLines = buildList {
            if (adviceArr != null) {
                for (i in 0 until adviceArr.length()) {
                    val s = adviceArr.optString(i, "").trim()
                    if (s.isNotEmpty()) add(s)
                }
            }
        }
        return AppSettings(
            activeModel = obj.optString("activeModel", AppSettings.DEFAULT_MODEL).ifBlank { AppSettings.DEFAULT_MODEL },
            defaultLowThreshold = obj.optInt("defaultLowThreshold", Item.DEFAULT_LOW_THRESHOLD).coerceAtLeast(1),
            dateStyle = dateStyle,
            privacyAccepted = obj.optBoolean("privacyAccepted", false),
            cachedAdviceDate = obj.optString("cachedAdviceDate", "").takeIf { it.isNotBlank() },
            cachedAdviceLines = adviceLines
        )
    }

    private fun txnToJson(txn: Txn): JSONObject {
        val obj = JSONObject()
        obj.put("id", txn.id)
        obj.put("type", txn.type.name)
        obj.put("timestamp", txn.timestamp)

        val linesArr = JSONArray()
        txn.lines.forEach { line ->
            val lObj = JSONObject()
            if (line.itemId != null) lObj.put("itemId", line.itemId)
            lObj.put("name", line.name)
            lObj.put("qty", line.qty)
            if (line.unitPrice != null) lObj.put("unitPrice", line.unitPrice)
            linesArr.put(lObj)
        }
        obj.put("lines", linesArr)

        obj.put("totalEtb", txn.totalEtb)

        val shortArr = JSONArray()
        txn.shortages.forEach { s ->
            val sObj = JSONObject()
            sObj.put("name", s.name)
            sObj.put("sentQty", s.sentQty)
            sObj.put("receivedQty", s.receivedQty)
            sObj.put("diff", s.diff)
            shortArr.put(sObj)
        }
        obj.put("shortages", shortArr)

        if (txn.reportAm != null) obj.put("reportAm", txn.reportAm)

        val photoArr = JSONArray()
        txn.photoFiles.forEach { photoArr.put(it) }
        obj.put("photoFiles", photoArr)

        val hashArr = JSONArray()
        txn.imageHashes.forEach { hashArr.put(it) }
        obj.put("imageHashes", hashArr)

        obj.put("status", txn.status.name)
        if (txn.voidedAt != null) obj.put("voidedAt", txn.voidedAt)
        if (txn.note != null) obj.put("note", txn.note)
        return obj
    }

    private fun jsonToTxn(obj: JSONObject): Txn {
        val type = runCatching { TxnType.valueOf(obj.optString("type", TxnType.SALE.name)) }
            .getOrDefault(TxnType.SALE)
        val status = runCatching { TxnStatus.valueOf(obj.optString("status", TxnStatus.ACTIVE.name)) }
            .getOrDefault(TxnStatus.ACTIVE)

        val linesArr = obj.optJSONArray("lines")
        val lines = buildList {
            if (linesArr != null) {
                for (i in 0 until linesArr.length()) {
                    val lObj = linesArr.optJSONObject(i) ?: continue
                    add(
                        Line(
                            itemId = lObj.optString("itemId", "").takeIf { it.isNotBlank() },
                            name = lObj.optString("name", ""),
                            qty = lObj.optInt("qty", 0),
                            unitPrice = if (lObj.has("unitPrice") && !lObj.isNull("unitPrice")) lObj.optDouble("unitPrice") else null
                        )
                    )
                }
            }
        }

        val shortArr = obj.optJSONArray("shortages")
        val shortages = buildList {
            if (shortArr != null) {
                for (i in 0 until shortArr.length()) {
                    val sObj = shortArr.optJSONObject(i) ?: continue
                    add(
                        CargoShortage(
                            name = sObj.optString("name", ""),
                            sentQty = sObj.optInt("sentQty", 0),
                            receivedQty = sObj.optInt("receivedQty", 0),
                            diff = sObj.optInt("diff", 0)
                        )
                    )
                }
            }
        }

        val photoArr = obj.optJSONArray("photoFiles")
        val photoFiles = buildList {
            if (photoArr != null) {
                for (i in 0 until photoArr.length()) {
                    val p = photoArr.optString(i, "")
                    if (p.isNotBlank()) add(p)
                }
            }
        }

        val hashArr = obj.optJSONArray("imageHashes")
        val imageHashes = buildList {
            if (hashArr != null) {
                for (i in 0 until hashArr.length()) {
                    val h = hashArr.optString(i, "")
                    if (h.isNotBlank()) add(h)
                }
            }
        }

        return Txn(
            id = obj.optString("id").ifBlank { java.util.UUID.randomUUID().toString() },
            type = type,
            timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
            lines = lines,
            totalEtb = obj.optDouble("totalEtb", 0.0),
            shortages = shortages,
            reportAm = obj.optString("reportAm", "").takeIf { it.isNotBlank() },
            photoFiles = photoFiles,
            imageHashes = imageHashes,
            status = status,
            voidedAt = if (obj.has("voidedAt") && !obj.isNull("voidedAt")) obj.optLong("voidedAt") else null,
            note = obj.optString("note", "").takeIf { it.isNotBlank() }
        )
    }
}
