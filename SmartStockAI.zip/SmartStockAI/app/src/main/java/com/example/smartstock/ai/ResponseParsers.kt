package com.example.smartstock.ai

import com.example.smartstock.data.CargoAnalysisResult
import com.example.smartstock.data.CargoReceivedItem
import com.example.smartstock.data.CargoSentItem
import com.example.smartstock.data.Confidence
import com.example.smartstock.data.SalesAnalysisResult
import com.example.smartstock.data.SalesParsedLine
import org.json.JSONObject

enum class AiErrorType {
    MISSING_KEY,
    INVALID_KEY,
    BAD_REQUEST,
    NO_INTERNET,
    TIMEOUT,
    BLOCKED_CONTENT,
    EMPTY_ANSWER,
    MAX_TOKENS,
    NO_MODEL_FOUND,
    SERVER_BUSY,
    PARSE_FAILED,
    IMAGE_FAILED,
    UNKNOWN
}

class AiException(
    val errorType: AiErrorType,
    override val message: String = errorType.name
) : Exception(message)

object ResponseParsers {

    private val EXCLUDED_MODEL_TOKENS = listOf(
        "image", "tts", "live", "audio", "embedding", "robotics", "omni", "transcribe", "translate"
    )

    /**
     * Strips markdown code fences (```json ... ``` or ``` ... ```) defensively.
     */
    fun stripCodeFences(raw: String): String {
        var text = raw.trim()
        if (text.startsWith("```")) {
            val firstNewline = text.indexOf('\n')
            if (firstNewline >= 0) {
                text = text.substring(firstNewline + 1)
            } else {
                text = text.removePrefix("```json").removePrefix("```")
            }
            if (text.trimEnd().endsWith("```")) {
                text = text.trimEnd().removeSuffix("```")
            }
        }
        return text.trim()
    }

    /**
     * Extracts text from Gemini API response candidates[0].content.parts[*].text.
     * Handles promptFeedback.blockReason, no candidates, finishReason MAX_TOKENS or SAFETY.
     */
    fun extractCandidateText(apiResponseBody: String): String {
        val root = try {
            JSONObject(apiResponseBody)
        } catch (_: Exception) {
            throw AiException(AiErrorType.PARSE_FAILED)
        }

        val promptFeedback = root.optJSONObject("promptFeedback")
        if (promptFeedback != null) {
            val blockReason = promptFeedback.optString("blockReason", "")
            if (blockReason.isNotBlank() && !blockReason.equals("BLOCK_REASON_UNSPECIFIED", ignoreCase = true)) {
                throw AiException(AiErrorType.BLOCKED_CONTENT)
            }
        }

        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            throw AiException(AiErrorType.EMPTY_ANSWER)
        }

        val first = candidates.optJSONObject(0) ?: throw AiException(AiErrorType.EMPTY_ANSWER)
        val finishReason = first.optString("finishReason", "")
        if (finishReason.equals("SAFETY", ignoreCase = true) ||
            finishReason.equals("PROHIBITED_CONTENT", ignoreCase = true) ||
            finishReason.equals("RECITATION", ignoreCase = true)
        ) {
            throw AiException(AiErrorType.BLOCKED_CONTENT)
        }
        if (finishReason.equals("MAX_TOKENS", ignoreCase = true)) {
            throw AiException(AiErrorType.MAX_TOKENS)
        }

        val content = first.optJSONObject("content") ?: throw AiException(AiErrorType.EMPTY_ANSWER)
        val parts = content.optJSONArray("parts") ?: throw AiException(AiErrorType.EMPTY_ANSWER)

        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            val t = part.optString("text", "")
            if (t.isNotEmpty()) sb.append(t)
        }

        val result = sb.toString().trim()
        if (result.isEmpty()) {
            throw AiException(AiErrorType.EMPTY_ANSWER)
        }
        return result
    }

    fun parseCargoResponse(rawText: String): CargoAnalysisResult {
        val cleaned = stripCodeFences(rawText)
        val root = try {
            JSONObject(cleaned)
        } catch (_: Exception) {
            throw AiException(AiErrorType.PARSE_FAILED)
        }

        val sentArr = root.optJSONArray("sent_items")
        val sentItems = buildList {
            if (sentArr != null) {
                for (i in 0 until sentArr.length()) {
                    val obj = sentArr.optJSONObject(i) ?: continue
                    val name = obj.optString("name", "").trim()
                    if (name.isEmpty()) continue
                    val qty = obj.optInt("qty", 0).coerceAtLeast(0)
                    val conf = Confidence.fromApi(obj.optString("confidence", "low"))
                    add(CargoSentItem(name = name, qty = qty, confidence = conf))
                }
            }
        }

        val recvArr = root.optJSONArray("received_items")
            ?: throw AiException(AiErrorType.PARSE_FAILED)
        val receivedItems = buildList {
            for (i in 0 until recvArr.length()) {
                val obj = recvArr.optJSONObject(i) ?: continue
                val name = obj.optString("name", "").trim()
                if (name.isEmpty()) continue
                val matchedId = if (obj.has("matched_stock_id") && !obj.isNull("matched_stock_id")) {
                    obj.optString("matched_stock_id", "").takeIf { it.isNotBlank() && it != "null" }
                } else {
                    null
                }
                val qty = obj.optInt("qty", 0).coerceAtLeast(0)
                val conf = Confidence.fromApi(obj.optString("confidence", "low"))
                add(CargoReceivedItem(name = name, matchedStockId = matchedId, qty = qty, confidence = conf))
            }
        }

        val reportAm = root.optString("report_am", "").trim()
        val photoNoteAm = root.optString("photo_note_am", "").trim()
        return CargoAnalysisResult(
            sentItems = sentItems,
            receivedItems = receivedItems,
            reportAm = reportAm,
            photoNoteAm = photoNoteAm
        )
    }

    fun parseSalesResponse(rawText: String): SalesAnalysisResult {
        val cleaned = stripCodeFences(rawText)
        val root = try {
            JSONObject(cleaned)
        } catch (_: Exception) {
            throw AiException(AiErrorType.PARSE_FAILED)
        }

        val linesArr = root.optJSONArray("lines")
            ?: throw AiException(AiErrorType.PARSE_FAILED)
        val lines = buildList {
            for (i in 0 until linesArr.length()) {
                val obj = linesArr.optJSONObject(i) ?: continue
                val name = obj.optString("name", "").trim()
                val raw = obj.optString("raw_text", name).trim()
                if (name.isEmpty()) continue
                val matchedId = if (obj.has("matched_stock_id") && !obj.isNull("matched_stock_id")) {
                    obj.optString("matched_stock_id", "").takeIf { it.isNotBlank() && it != "null" }
                } else {
                    null
                }
                val qty = obj.optInt("qty", 1).coerceAtLeast(0)
                val unitPrice = optNullableDouble(obj, "unit_price")
                val lineTotal = optNullableDouble(obj, "line_total")
                val conf = Confidence.fromApi(obj.optString("confidence", "low"))
                add(
                    SalesParsedLine(
                        rawText = raw,
                        name = name,
                        matchedStockId = matchedId,
                        qty = qty,
                        unitPrice = unitPrice,
                        lineTotal = lineTotal,
                        confidence = conf
                    )
                )
            }
        }

        val grandTotal = optNullableDouble(root, "written_grand_total")
        val notesAm = root.optString("notes_am", "").trim()
        return SalesAnalysisResult(
            lines = lines,
            writtenGrandTotal = grandTotal,
            notesAm = notesAm
        )
    }

    fun parseAdviceResponse(rawText: String): List<String> {
        val cleaned = stripCodeFences(rawText)
        val root = try {
            JSONObject(cleaned)
        } catch (_: Exception) {
            throw AiException(AiErrorType.PARSE_FAILED)
        }
        val arr = root.optJSONArray("suggestions") ?: throw AiException(AiErrorType.PARSE_FAILED)
        return buildList {
            for (i in 0 until arr.length()) {
                val line = arr.optString(i, "").trim()
                if (line.isNotEmpty()) add(line)
            }
        }.take(5)
    }

    /**
     * Filters and ranks Gemini Flash models from one or more /v1beta/models JSON payloads.
     * Rules:
     * - name starts with "models/gemini-"
     * - contains "flash"
     * - supports "generateContent"
     * - does NOT contain image, tts, live, audio, embedding, robotics, omni, transcribe, translate
     * Ranking:
     * 1. stable before preview/exp
     * 2. higher version first
     * 3. non-lite before lite
     */
    fun selectBestFlashModel(modelObjects: List<JSONObject>): String? {
        val eligible = modelObjects.mapNotNull { obj ->
            val fullName = obj.optString("name", "")
            if (!fullName.startsWith("models/gemini-")) return@mapNotNull null
            val lower = fullName.lowercase()
            if (!lower.contains("flash")) return@mapNotNull null
            if (EXCLUDED_MODEL_TOKENS.any { lower.contains(it) }) return@mapNotNull null

            val methods = obj.optJSONArray("supportedGenerationMethods") ?: return@mapNotNull null
            var supportsGen = false
            for (i in 0 until methods.length()) {
                if (methods.optString(i) == "generateContent") {
                    supportsGen = true
                    break
                }
            }
            if (!supportsGen) return@mapNotNull null
            fullName.removePrefix("models/")
        }

        if (eligible.isEmpty()) return null

        return eligible.sortedWith(
            compareByDescending<String> { isStableModel(it) }
                .thenByDescending { parseVersionMajor(it) }
                .thenByDescending { parseVersionMinor(it) }
                .thenByDescending { !it.lowercase().contains("lite") }
                .thenBy { it }
        ).first()
    }

    private fun isStableModel(modelId: String): Boolean {
        val lower = modelId.lowercase()
        return !lower.contains("preview") && !lower.contains("exp") && !lower.contains("experimental")
    }

    private fun parseVersionMajor(modelId: String): Int {
        val match = Regex("gemini-(\\d+)(?:\\.(\\d+))?").find(modelId.lowercase())
        return match?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
    }

    private fun parseVersionMinor(modelId: String): Int {
        val match = Regex("gemini-(\\d+)(?:\\.(\\d+))?").find(modelId.lowercase())
        return match?.groupValues?.getOrNull(2)?.toIntOrNull() ?: 0
    }

    private fun optNullableDouble(obj: JSONObject, key: String): Double? {
        if (!obj.has(key) || obj.isNull(key)) return null
        val v = obj.optDouble(key, Double.NaN)
        return if (v.isNaN()) null else v
    }
}
