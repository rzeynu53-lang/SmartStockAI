package com.example.smartstock.ai

import com.example.smartstock.data.CargoAnalysisResult
import com.example.smartstock.data.Item
import com.example.smartstock.data.SalesAnalysisResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.util.concurrent.TimeUnit
import kotlin.random.Random

enum class ProgressPhase {
    PREPARING,
    UPLOADING,
    ANALYZING,
    RETRYING,
    RESOLVING_MODEL,
    FIXING_JSON,
    DONE
}

data class AiProgressEvent(
    val percent: Int,
    val phase: ProgressPhase,
    val retryAttempt: Int = 0
)

class GeminiClient {

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .callTimeout(180, TimeUnit.SECONDS)
        .build()

    private val modelResolver = ModelResolver(client)

    suspend fun analyzeCargo(
        apiKey: String,
        model: String,
        catalogue: List<Item>,
        sentImage: ProcessedImage?,
        receivedImage: ProcessedImage,
        isEnglish: Boolean = false,
        onModelResolved: (String) -> Unit,
        onProgress: (AiProgressEvent) -> Unit
    ): CargoAnalysisResult {
        val images = buildList {
            if (sentImage != null) add(sentImage)
            add(receivedImage)
        }
        val rawText = generateWithFallbackAndParseRetry(
            apiKey = apiKey,
            initialModel = model,
            systemInstruction = GeminiPrompts.cargoSystemInstruction(isEnglish),
            userText = GeminiPrompts.cargoUserPrompt(catalogue, hasSentPhoto = sentImage != null),
            images = images,
            responseSchema = GeminiPrompts.cargoResponseSchema(),
            onModelResolved = onModelResolved,
            onProgress = onProgress,
            parser = { ResponseParsers.parseCargoResponse(it) }
        )
        onProgress(AiProgressEvent(100, ProgressPhase.DONE))
        return rawText
    }

    suspend fun analyzeSales(
        apiKey: String,
        model: String,
        catalogue: List<Item>,
        images: List<ProcessedImage>,
        isEnglish: Boolean = false,
        onModelResolved: (String) -> Unit,
        onProgress: (AiProgressEvent) -> Unit
    ): SalesAnalysisResult {
        val result = generateWithFallbackAndParseRetry(
            apiKey = apiKey,
            initialModel = model,
            systemInstruction = GeminiPrompts.salesSystemInstruction(isEnglish),
            userText = GeminiPrompts.salesUserPrompt(catalogue, images.size),
            images = images,
            responseSchema = GeminiPrompts.salesResponseSchema(),
            onModelResolved = onModelResolved,
            onProgress = onProgress,
            parser = { ResponseParsers.parseSalesResponse(it) }
        )
        onProgress(AiProgressEvent(100, ProgressPhase.DONE))
        return result
    }

    suspend fun fetchWeeklyAdvice(
        apiKey: String,
        model: String,
        summaryText: String,
        isEnglish: Boolean = false,
        onModelResolved: (String) -> Unit
    ): List<String> {
        return generateWithFallbackAndParseRetry(
            apiKey = apiKey,
            initialModel = model,
            systemInstruction = GeminiPrompts.weeklyAdviceSystemInstruction(isEnglish),
            userText = summaryText,
            images = emptyList(),
            responseSchema = GeminiPrompts.weeklyAdviceResponseSchema(),
            onModelResolved = onModelResolved,
            onProgress = {},
            parser = { ResponseParsers.parseAdviceResponse(it) }
        )
    }

    suspend fun testApiKey(
        apiKey: String,
        model: String,
        onModelResolved: (String) -> Unit
    ): Boolean {
        if (apiKey.isBlank()) throw AiException(AiErrorType.MISSING_KEY)
        val schema = JSONObject()
            .put("type", "OBJECT")
            .put("properties", JSONObject().put("ok", JSONObject().put("type", "BOOLEAN")))
            .put("required", JSONArray(listOf("ok")))
        val body = buildRequestBodyJson(
            systemInstruction = "Return {\"ok\": true}.",
            userText = "ping",
            images = emptyList(),
            responseSchema = schema
        )
        executeWithRetriesAndModelFallback(
            apiKey = apiKey,
            initialModel = model,
            requestJson = body,
            onModelResolved = onModelResolved,
            onProgress = {}
        )
        return true
    }

    private suspend fun <T> generateWithFallbackAndParseRetry(
        apiKey: String,
        initialModel: String,
        systemInstruction: String,
        userText: String,
        images: List<ProcessedImage>,
        responseSchema: JSONObject,
        onModelResolved: (String) -> Unit,
        onProgress: (AiProgressEvent) -> Unit,
        parser: (String) -> T
    ): T {
        if (apiKey.isBlank()) throw AiException(AiErrorType.MISSING_KEY)

        var activeModel = initialModel
        val firstPayload = buildRequestBodyJson(systemInstruction, userText, images, responseSchema)
        val firstResponse = executeWithRetriesAndModelFallback(
            apiKey = apiKey,
            initialModel = activeModel,
            requestJson = firstPayload,
            onModelResolved = {
                activeModel = it
                onModelResolved(it)
            },
            onProgress = onProgress
        )

        return try {
            parser(firstResponse)
        } catch (e: AiException) {
            if (e.errorType != AiErrorType.PARSE_FAILED) throw e
            // Retry once asking strictly for valid JSON only
            onProgress(AiProgressEvent(85, ProgressPhase.FIXING_JSON))
            val strictPrompt = "$userText\n\nIMPORTANT: Your previous output was not valid JSON. Return ONLY valid JSON matching the schema, with no markdown fences or extra text."
            val retryPayload = buildRequestBodyJson(systemInstruction, strictPrompt, images, responseSchema)
            val secondResponse = executeWithRetriesAndModelFallback(
                apiKey = apiKey,
                initialModel = activeModel,
                requestJson = retryPayload,
                onModelResolved = {
                    activeModel = it
                    onModelResolved(it)
                },
                onProgress = onProgress
            )
            parser(secondResponse)
        }
    }

    private suspend fun executeWithRetriesAndModelFallback(
        apiKey: String,
        initialModel: String,
        requestJson: String,
        onModelResolved: (String) -> Unit,
        onProgress: (AiProgressEvent) -> Unit
    ): String {
        var currentModel = initialModel
        var notFoundFallbackTried = false
        var quotaFallbackTried = false

        while (true) {
            try {
                return executeSingleModelWithTransientRetries(
                    apiKey = apiKey,
                    model = currentModel,
                    requestJson = requestJson,
                    onProgress = onProgress
                )
            } catch (e: ModelNotFoundException) {
                if (notFoundFallbackTried) {
                    throw AiException(AiErrorType.NO_MODEL_FOUND)
                }
                notFoundFallbackTried = true
                onProgress(AiProgressEvent(60, ProgressPhase.RESOLVING_MODEL))
                val winner = modelResolver.resolveBestFlashModel(apiKey)
                currentModel = winner
                onModelResolved(winner)
            } catch (e: AiException) {
                if (e.errorType == AiErrorType.SERVER_BUSY && !quotaFallbackTried && currentModel != "gemini-3.5-flash-lite") {
                    quotaFallbackTried = true
                    onProgress(AiProgressEvent(65, ProgressPhase.RESOLVING_MODEL))
                    currentModel = "gemini-3.5-flash-lite"
                    onModelResolved(currentModel)
                } else {
                    throw e
                }
            }
        }
    }

    private suspend fun executeSingleModelWithTransientRetries(
        apiKey: String,
        model: String,
        requestJson: String,
        onProgress: (AiProgressEvent) -> Unit
    ): String = withContext(Dispatchers.IO) {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val jsonMediaType = "application/json; charset=utf-8".toMediaType()
        var currentPercent = 25

        for (attempt in 0..3) {
            val rawBody = requestJson.toRequestBody(jsonMediaType)
            val countingBody = CountingRequestBody(rawBody) { written, total ->
                val fraction = (written.toDouble() / total.coerceAtLeast(1L).toDouble()).coerceIn(0.0, 1.0)
                val mapped = (25 + (fraction * 35.0).toInt()).coerceIn(25, 60)
                if (mapped > currentPercent) {
                    currentPercent = mapped
                    onProgress(AiProgressEvent(currentPercent, ProgressPhase.UPLOADING))
                }
            }

            val request = Request.Builder()
                .url(url)
                .header("x-goog-api-key", apiKey)
                .post(countingBody)
                .build()

            val response = coroutineScope {
                var creepPercent = maxOf(currentPercent, 60)
                val creepJob = launch {
                    // Wait until upload likely finishes, then creep 1% every ~1.5s up to 95%
                    delay(1200L)
                    while (isActive && creepPercent < 95) {
                        if (currentPercent >= 60 || attempt > 0) {
                            creepPercent = (creepPercent + 1).coerceAtMost(95)
                            currentPercent = maxOf(currentPercent, creepPercent)
                            onProgress(AiProgressEvent(currentPercent, ProgressPhase.ANALYZING))
                        }
                        delay(1500L)
                    }
                }
                try {
                    onProgress(AiProgressEvent(maxOf(currentPercent, 25), ProgressPhase.UPLOADING))
                    client.newCall(request).execute()
                } catch (ce: CancellationException) {
                    throw ce
                } catch (_: SocketTimeoutException) {
                    throw AiException(AiErrorType.TIMEOUT)
                } catch (_: IOException) {
                    throw AiException(AiErrorType.NO_INTERNET)
                } finally {
                    creepJob.cancel()
                }
            }

            response.use { resp ->
                val code = resp.code
                val bodyStr = resp.body?.string().orEmpty()
                when (code) {
                    in 200..299 -> {
                        return@withContext ResponseParsers.extractCandidateText(bodyStr)
                    }
                    404 -> throw ModelNotFoundException()
                    400 -> throw AiException(AiErrorType.BAD_REQUEST)
                    401, 403 -> throw AiException(AiErrorType.INVALID_KEY)
                    429, 500, 503 -> {
                        if (attempt >= 3) {
                            throw AiException(AiErrorType.SERVER_BUSY)
                        }
                        val nextRetryNum = attempt + 1
                        currentPercent = maxOf(currentPercent, 60)
                        onProgress(
                            AiProgressEvent(
                                percent = currentPercent,
                                phase = ProgressPhase.RETRYING,
                                retryAttempt = nextRetryNum
                            )
                        )
                        val retryAfterHeader = resp.header("Retry-After")?.toLongOrNull()
                        val waitMs = if (retryAfterHeader != null && retryAfterHeader in 1L..10L) {
                            retryAfterHeader * 1000L
                        } else {
                            Random.nextLong(2000L, 4001L)
                        }
                        delay(waitMs)
                    }
                    else -> throw AiException(AiErrorType.UNKNOWN)
                }
            }
        }
        throw AiException(AiErrorType.SERVER_BUSY)
    }

    private fun buildRequestBodyJson(
        systemInstruction: String,
        userText: String,
        images: List<ProcessedImage>,
        responseSchema: JSONObject
    ): String {
        val root = JSONObject()

        root.put(
            "systemInstruction",
            JSONObject().put(
                "parts",
                JSONArray().put(JSONObject().put("text", systemInstruction))
            )
        )

        val userParts = JSONArray()
        userParts.put(JSONObject().put("text", userText))
        for (img in images) {
            userParts.put(
                JSONObject().put(
                    "inlineData",
                    JSONObject()
                        .put("mimeType", "image/jpeg")
                        .put("data", img.base64)
                )
            )
        }

        root.put(
            "contents",
            JSONArray().put(
                JSONObject()
                    .put("role", "user")
                    .put("parts", userParts)
            )
        )

        root.put(
            "generationConfig",
            JSONObject()
                .put("temperature", 0.0)
                .put("responseMimeType", "application/json")
                .put("responseSchema", responseSchema)
                .put("maxOutputTokens", 8192)
        )

        return root.toString()
    }

    private class ModelNotFoundException : Exception()
}
