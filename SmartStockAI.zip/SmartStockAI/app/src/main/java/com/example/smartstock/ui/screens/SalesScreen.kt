package com.example.smartstock.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.smartstock.R
import com.example.smartstock.ai.ImageProcessor
import com.example.smartstock.data.Confidence
import com.example.smartstock.data.Item
import com.example.smartstock.domain.EditableSaleLine
import com.example.smartstock.domain.SalesLineAction
import com.example.smartstock.domain.StockEngine
import com.example.smartstock.ui.AppUiState
import com.example.smartstock.ui.components.AiProgressCard
import com.example.smartstock.ui.components.ConfidenceChip
import com.example.smartstock.ui.components.EmptyStateCard
import com.example.smartstock.ui.components.ErrorBanner
import com.example.smartstock.ui.components.StatusBadge
import com.example.smartstock.ui.components.UriThumbnail
import com.example.smartstock.ui.theme.LowConfidenceTintDark
import com.example.smartstock.ui.theme.LowConfidenceTintLight
import com.example.smartstock.ui.theme.ShortageRed
import com.example.smartstock.ui.theme.WarningAmber
import com.example.smartstock.util.Formatters

private const val MAX_SALES_PHOTOS = 3

@Composable
fun SalesScreen(
    state: AppUiState,
    onAnalyze: (List<Uri>) -> Unit,
    onCancelAnalyze: () -> Unit,
    onDismissError: () -> Unit,
    onUpdateQty: (String, Int) -> Unit,
    onUpdatePrice: (String, Double?) -> Unit,
    onRemoveLine: (String) -> Unit,
    onMapToExisting: (String, Item) -> Unit,
    onSetAction: (String, SalesLineAction) -> Unit,
    onAddManualLine: (String, Int, Double?) -> Unit,
    onConfirmSale: (onSuccess: () -> Unit) -> Unit,
    onShowMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var photoUriStrings by rememberSaveable { mutableStateOf<List<String>>(emptyList()) }
    var pendingCameraUriStr by rememberSaveable { mutableStateOf<String?>(null) }
    var showAddLineDialog by remember { mutableStateOf(false) }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val captured = pendingCameraUriStr
        if (success && captured != null && photoUriStrings.size < MAX_SALES_PHOTOS) {
            photoUriStrings = photoUriStrings + captured
        }
        pendingCameraUriStr = null
    }

    val pickGalleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = MAX_SALES_PHOTOS)
    ) { uris ->
        if (uris.isNotEmpty()) {
            val combined = (photoUriStrings + uris.map { it.toString() }).distinct().take(MAX_SALES_PHOTOS)
            photoUriStrings = combined
        }
    }

    val sales = state.sales
    val computedTotal = StockEngine.computeSalesTotal(sales.lines)
    val canConfirm = !sales.isSubmitting && StockEngine.canConfirmSale(sales.lines)
    val hasUnresolved = sales.lines.any { it.action == SalesLineAction.UNRESOLVED }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Post-confirmation today's total summary banner
        sales.confirmedTodayTotalEtb?.let { todayTotal ->
            item(key = "sales_confirmed_banner") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Text(
                        text = stringResource(
                            R.string.sales_confirmed_banner,
                            Formatters.formatMoney(todayTotal)
                        ),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }

        // Photo Picker Card (up to 3 photos)
        item(key = "sales_photo_picker") {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = stringResource(R.string.sales_photos_title),
                        style = MaterialTheme.typography.titleMedium
                    )
                    if (photoUriStrings.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(photoUriStrings, key = { it }) { uriStr ->
                                Box {
                                    UriThumbnail(uri = Uri.parse(uriStr), size = 88.dp)
                                    IconButton(
                                        onClick = { photoUriStrings = photoUriStrings.filterNot { it == uriStr } },
                                        modifier = Modifier.align(Alignment.TopEnd)
                                    ) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = stringResource(R.string.action_remove),
                                            tint = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilledTonalButton(
                            onClick = {
                                if (photoUriStrings.size >= MAX_SALES_PHOTOS) {
                                    onShowMessage(context.getString(R.string.sales_max_photos_reached))
                                } else {
                                    val uri = ImageProcessor.createCameraPhotoUri(context)
                                    pendingCameraUriStr = uri.toString()
                                    takePictureLauncher.launch(uri)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                        ) {
                            Text(stringResource(R.string.action_take_photo))
                        }
                        OutlinedButton(
                            onClick = {
                                if (photoUriStrings.size >= MAX_SALES_PHOTOS) {
                                    onShowMessage(context.getString(R.string.sales_max_photos_reached))
                                } else {
                                    pickGalleryLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 48.dp)
                        ) {
                            Text(stringResource(R.string.action_pick_gallery))
                        }
                    }

                    Button(
                        onClick = {
                            if (photoUriStrings.isEmpty()) {
                                onShowMessage(context.getString(R.string.sales_err_need_photo))
                            } else {
                                onAnalyze(photoUriStrings.map(Uri::parse))
                            }
                        },
                        enabled = !sales.isAnalyzing && photoUriStrings.isNotEmpty(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 52.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.sales_btn_analyze),
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
        }

        // Progress Card
        if (sales.isAnalyzing) {
            item(key = "sales_progress") {
                AiProgressCard(
                    percent = sales.progressPercent,
                    statusText = sales.progressStatus,
                    onCancel = onCancelAnalyze
                )
            }
        }

        // Error Banner
        sales.errorMessage?.let { err ->
            item(key = "sales_error") {
                ErrorBanner(message = err, onDismiss = onDismissError)
            }
        }

        // Duplicate-photo warning
        if (sales.duplicatePhotoWarning) {
            item(key = "sales_dup_warn") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(R.string.sales_warn_duplicate_photo),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
        }

        // Empty State
        if (!sales.isAnalyzing && sales.lines.isEmpty()) {
            item(key = "sales_empty") {
                EmptyStateCard(
                    title = stringResource(R.string.sales_empty_title),
                    body = stringResource(R.string.sales_empty_body)
                )
            }
        }

        // Editable Sales Lines
        if (sales.lines.isNotEmpty()) {
            item(key = "sales_total_header") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = stringResource(R.string.sales_total_label),
                                    style = MaterialTheme.typography.labelLarge
                                )
                                Text(
                                    text = stringResource(R.string.money_format, Formatters.formatMoney(computedTotal)),
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                            TextButton(
                                onClick = { showAddLineDialog = true },
                                modifier = Modifier.heightIn(min = 48.dp)
                            ) {
                                Text(stringResource(R.string.sales_btn_add_line))
                            }
                        }

                        if (StockEngine.hasGrandTotalMismatch(computedTotal, sales.writtenGrandTotal)) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = stringResource(
                                    R.string.sales_warn_grand_total,
                                    Formatters.formatMoney(computedTotal),
                                    Formatters.formatMoney(sales.writtenGrandTotal ?: 0.0)
                                ),
                                style = MaterialTheme.typography.bodyMedium,
                                color = ShortageRed,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        if (sales.notesAm.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = sales.notesAm,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
            }

            items(sales.lines, key = { it.tempId }) { line ->
                EditableSaleLineCard(
                    line = line,
                    catalogue = state.items,
                    onUpdateQty = { delta -> onUpdateQty(line.tempId, delta) },
                    onUpdatePrice = { p -> onUpdatePrice(line.tempId, p) },
                    onRemove = { onRemoveLine(line.tempId) },
                    onMapExisting = { item -> onMapToExisting(line.tempId, item) },
                    onSetAction = { action -> onSetAction(line.tempId, action) }
                )
            }

            item(key = "sales_confirm_footer") {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (hasUnresolved) {
                        Text(
                            text = stringResource(R.string.sales_unmatched_hint),
                            style = MaterialTheme.typography.bodyMedium,
                            color = WarningAmber,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Button(
                        onClick = {
                            onConfirmSale {
                                photoUriStrings = emptyList()
                            }
                        },
                        enabled = canConfirm,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 56.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.sales_btn_confirm),
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
        }
    }

    if (showAddLineDialog) {
        AddManualSaleLineDialog(
            onDismiss = { showAddLineDialog = false },
            onAdd = { name, qty, price ->
                onAddManualLine(name, qty, price)
                showAddLineDialog = false
            }
        )
    }
}

@Composable
private fun EditableSaleLineCard(
    line: EditableSaleLine,
    catalogue: List<Item>,
    onUpdateQty: (Int) -> Unit,
    onUpdatePrice: (Double?) -> Unit,
    onRemove: () -> Unit,
    onMapExisting: (Item) -> Unit,
    onSetAction: (SalesLineAction) -> Unit
) {
    val isDark = isSystemInDarkTheme()
    val warnings = remember(line, catalogue) { StockEngine.computeSaleLineWarnings(line, catalogue) }
    var priceText by remember(line.tempId, line.unitPrice) {
        mutableStateOf(line.unitPrice?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() }.orEmpty())
    }
    var actionMenuExpanded by remember { mutableStateOf(false) }

    val isIgnored = line.action == SalesLineAction.IGNORE
    val isLowConf = line.confidence == Confidence.LOW
    val cardBg = when {
        isIgnored -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        isLowConf -> if (isDark) LowConfidenceTintDark else LowConfidenceTintLight
        else -> MaterialTheme.colorScheme.surface
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = line.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        textDecoration = if (isIgnored) TextDecoration.LineThrough else TextDecoration.None
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        ConfidenceChip(confidence = line.confidence)
                        when (line.action) {
                            SalesLineAction.UNRESOLVED -> StatusBadge(
                                text = stringResource(R.string.sales_chip_new),
                                backgroundColor = WarningAmber,
                                contentColor = Color.White
                            )
                            SalesLineAction.CREATE_NEW -> StatusBadge(
                                text = stringResource(R.string.sales_action_create),
                                backgroundColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            SalesLineAction.IGNORE -> StatusBadge(
                                text = stringResource(R.string.sales_ignored_label),
                                backgroundColor = MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            SalesLineAction.MATCHED -> Unit
                        }
                    }
                }
                IconButton(onClick = onRemove, modifier = Modifier.size(48.dp)) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = stringResource(R.string.action_remove),
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }

            // Unmatched resolution menu (map / create / ignore)
            if (line.action != SalesLineAction.MATCHED) {
                Box {
                    OutlinedButton(
                        onClick = { actionMenuExpanded = true },
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text(stringResource(R.string.sales_action_map))
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
                    }
                    DropdownMenu(expanded = actionMenuExpanded, onDismissRequest = { actionMenuExpanded = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.sales_action_create)) },
                            onClick = {
                                onSetAction(SalesLineAction.CREATE_NEW)
                                actionMenuExpanded = false
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.sales_action_ignore)) },
                            onClick = {
                                onSetAction(SalesLineAction.IGNORE)
                                actionMenuExpanded = false
                            }
                        )
                        catalogue.forEach { item ->
                            DropdownMenuItem(
                                text = { Text("${item.name} (${item.qty} ${item.unit})") },
                                onClick = {
                                    onMapExisting(item)
                                    actionMenuExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // Qty +/-, Unit Price, Computed Line Total
            if (!isIgnored) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(
                            onClick = { onUpdateQty(-1) },
                            enabled = line.qty > 0,
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Text("−", style = MaterialTheme.typography.titleLarge)
                        }
                        Text(
                            text = line.qty.toString(),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        OutlinedButton(
                            onClick = { onUpdateQty(1) },
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Text("+", style = MaterialTheme.typography.titleLarge)
                        }
                    }

                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { raw ->
                            priceText = raw
                            onUpdatePrice(raw.trim().toDoubleOrNull())
                        },
                        label = { Text(stringResource(R.string.price_label)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    Text(
                        text = stringResource(R.string.money_format, Formatters.formatMoney(line.computedLineTotal)),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                // Warnings
                warnings.aboveStockRemaining?.let { remaining ->
                    Text(
                        text = stringResource(R.string.sales_warn_above_stock, remaining),
                        style = MaterialTheme.typography.labelLarge,
                        color = ShortageRed
                    )
                }
                warnings.cataloguePriceForDiffWarning?.let { catalogPrice ->
                    Text(
                        text = stringResource(R.string.sales_warn_price_diff, Formatters.formatMoney(catalogPrice)),
                        style = MaterialTheme.typography.labelLarge,
                        color = WarningAmber
                    )
                }
                warnings.lineMathMismatch?.let { (calc, written) ->
                    Text(
                        text = stringResource(
                            R.string.sales_warn_line_math,
                            Formatters.formatMoney(calc),
                            Formatters.formatMoney(written)
                        ),
                        style = MaterialTheme.typography.labelLarge,
                        color = WarningAmber
                    )
                }
            }
        }
    }
}

@Composable
private fun AddManualSaleLineDialog(
    onDismiss: () -> Unit,
    onAdd: (String, Int, Double?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var qtyText by remember { mutableStateOf("1") }
    var priceText by remember { mutableStateOf("") }
    var nameError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.sales_btn_add_line)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        nameError = false
                    },
                    label = { Text(stringResource(R.string.stock_field_name)) },
                    isError = nameError,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = qtyText,
                    onValueChange = { qtyText = it.filter { ch -> ch.isDigit() } },
                    label = { Text(stringResource(R.string.stock_field_qty)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = priceText,
                    onValueChange = { priceText = it },
                    label = { Text(stringResource(R.string.price_label)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val trimmed = name.trim()
                if (trimmed.isEmpty()) {
                    nameError = true
                } else {
                    onAdd(trimmed, qtyText.toIntOrNull()?.coerceAtLeast(1) ?: 1, priceText.trim().toDoubleOrNull())
                }
            }) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(stringResource(R.string.action_add))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.action_cancel))
            }
        }
    )
}
