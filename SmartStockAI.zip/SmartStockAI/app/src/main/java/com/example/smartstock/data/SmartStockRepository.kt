package com.example.smartstock.data

import android.content.Context
import java.io.File
import java.io.FileOutputStream

/**
 * Persistence layer:
 * - Items & Settings: SharedPreferences "smartstock_v2" as JSON strings with schemaVersion.
 * - History: filesDir/history.json, written atomically via temp file + rename.
 * - Thumbnails: filesDir/evidence/ (JPEG, max 320 px, quality 70).
 */
class SmartStockRepository(context: Context) {

    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val historyFile = File(appContext.filesDir, HISTORY_FILE_NAME)
    private val historyTempFile = File(appContext.filesDir, "$HISTORY_FILE_NAME.tmp")
    val evidenceDir: File = File(appContext.filesDir, EVIDENCE_DIR_NAME).apply { mkdirs() }

    private val lock = Any()

    fun loadItems(): List<Item> = synchronized(lock) {
        JsonCodec.decodeItems(prefs.getString(KEY_ITEMS, null))
    }

    fun saveItems(items: List<Item>) = synchronized(lock) {
        val json = JsonCodec.encodeItems(items)
        prefs.edit().putString(KEY_ITEMS, json).commit()
    }

    fun loadSettings(): AppSettings = synchronized(lock) {
        JsonCodec.decodeSettings(prefs.getString(KEY_SETTINGS, null))
    }

    fun saveSettings(settings: AppSettings) = synchronized(lock) {
        val json = JsonCodec.encodeSettings(settings)
        prefs.edit().putString(KEY_SETTINGS, json).commit()
    }

    fun loadHistory(): List<Txn> = synchronized(lock) {
        if (!historyFile.exists()) return emptyList()
        return try {
            val content = historyFile.readText(Charsets.UTF_8)
            JsonCodec.decodeHistory(content).sortedByDescending { it.timestamp }
        } catch (_: Exception) {
            emptyList()
        }
    }

    /**
     * Writes history atomically: write to temp file, fsync, then rename to history.json.
     */
    fun saveHistoryAtomic(history: List<Txn>) = synchronized(lock) {
        val json = JsonCodec.encodeHistory(history)
        FileOutputStream(historyTempFile).use { fos ->
            fos.write(json.toByteArray(Charsets.UTF_8))
            fos.flush()
            try {
                fos.fd.sync()
            } catch (_: Exception) {
                // Ignore sync errors on virtual filesystems
            }
        }
        if (historyFile.exists() && !historyTempFile.renameTo(historyFile)) {
            historyFile.delete()
            historyTempFile.renameTo(historyFile)
        } else if (!historyFile.exists()) {
            historyTempFile.renameTo(historyFile)
        }
    }

    /**
     * Atomically updates both stock items and transaction history.
     */
    fun commitItemsAndHistory(items: List<Item>, history: List<Txn>) = synchronized(lock) {
        saveHistoryAtomic(history)
        saveItems(items)
    }

    fun evidenceFile(fileName: String): File {
        return File(evidenceDir, fileName)
    }

    fun exportBackupJson(items: List<Item>, settings: AppSettings, history: List<Txn>): String {
        return JsonCodec.encodeBackup(items, settings, history)
    }

    fun restoreFromBackup(payload: BackupPayload) = synchronized(lock) {
        saveHistoryAtomic(payload.history)
        saveItems(payload.items)
        saveSettings(payload.settings)
    }

    fun clearAllData() = synchronized(lock) {
        prefs.edit()
            .remove(KEY_ITEMS)
            .apply()
        if (historyFile.exists()) historyFile.delete()
        if (historyTempFile.exists()) historyTempFile.delete()
        evidenceDir.listFiles()?.forEach { it.delete() }
    }

    companion object {
        private const val PREFS_NAME = "smartstock_v2"
        private const val KEY_ITEMS = "items_json"
        private const val KEY_SETTINGS = "settings_json"
        private const val HISTORY_FILE_NAME = "history.json"
        private const val EVIDENCE_DIR_NAME = "evidence"
    }
}
