package com.example.smartstock.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Teal/Green Material 3 Palette
val TealPrimary = Color(0xFF00695C)
val TealOnPrimary = Color(0xFFFFFFFF)
val TealPrimaryContainer = Color(0xFFB2DFDB)
val TealOnPrimaryContainer = Color(0xFF00201C)

val GreenSecondary = Color(0xFF2E7D32)
val GreenOnSecondary = Color(0xFFFFFFFF)
val GreenSecondaryContainer = Color(0xFFC8E6C9)
val GreenOnSecondaryContainer = Color(0xFF0A2E0E)

val TealTertiary = Color(0xFF00838F)
val TealOnTertiary = Color(0xFFFFFFFF)

val LightBackground = Color(0xFFF6FBF9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE0ECEA)
val LightOnSurface = Color(0xFF171D1C)
val LightOnSurfaceVariant = Color(0xFF3F4947)

val DarkPrimary = Color(0xFF80CBC4)
val DarkOnPrimary = Color(0xFF003731)
val DarkPrimaryContainer = Color(0xFF005048)
val DarkOnPrimaryContainer = Color(0xFFB2DFDB)

val DarkSecondary = Color(0xFFA5D6A7)
val DarkOnSecondary = Color(0xFF0E3814)
val DarkSecondaryContainer = Color(0xFF1B5E20)
val DarkOnSecondaryContainer = Color(0xFFC8E6C9)

val DarkBackground = Color(0xFF0F1514)
val DarkSurface = Color(0xFF171D1C)
val DarkSurfaceVariant = Color(0xFF273331)
val DarkOnSurface = Color(0xFFE0E3E2)
val DarkOnSurfaceVariant = Color(0xFFBEC9C6)

// Semantic status colors
val LowStockTintLight = Color(0xFFFFEBEE)
val LowStockTintDark = Color(0xFF441A1E)
val LowConfidenceTintLight = Color(0xFFFFF8E1)
val LowConfidenceTintDark = Color(0xFF423612)
val ShortageRed = Color(0xFFC62828)
val ExtraBlue = Color(0xFF1565C0)
val MatchGreen = Color(0xFF2E7D32)
val WarningAmber = Color(0xFFEF6C00)

private val LightColors = lightColorScheme(
    primary = TealPrimary,
    onPrimary = TealOnPrimary,
    primaryContainer = TealPrimaryContainer,
    onPrimaryContainer = TealOnPrimaryContainer,
    secondary = GreenSecondary,
    onSecondary = GreenOnSecondary,
    secondaryContainer = GreenSecondaryContainer,
    onSecondaryContainer = GreenOnSecondaryContainer,
    tertiary = TealTertiary,
    onTertiary = TealOnTertiary,
    background = LightBackground,
    onBackground = LightOnSurface,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    error = Color(0xFFBA1A1A),
    onError = Color(0xFFFFFFFF),
    errorContainer = Color(0xFFFFDAD6),
    onErrorContainer = Color(0xFF410002)
)

private val DarkColors = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DarkOnPrimary,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = DarkOnPrimaryContainer,
    secondary = DarkSecondary,
    onSecondary = DarkOnSecondary,
    secondaryContainer = DarkSecondaryContainer,
    onSecondaryContainer = DarkOnSecondaryContainer,
    tertiary = Color(0xFF80DEEA),
    onTertiary = Color(0xFF00363D),
    background = DarkBackground,
    onBackground = DarkOnSurface,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6)
)

// Generous lineHeight so Ethiopic/Ge'ez glyphs are never clipped
val SmartStockTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 36.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 30.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 26.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 26.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 22.sp
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 22.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 18.sp
    )
)

@Composable
fun SmartStockTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = SmartStockTypography,
        content = content
    )
}
