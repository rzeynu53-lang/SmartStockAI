package com.example.smartstock.domain

import com.example.smartstock.data.CargoShortage
import com.example.smartstock.data.Confidence
import com.example.smartstock.data.Item
import com.example.smartstock.data.Line
import com.example.smartstock.data.Txn
import com.example.smartstock.data.TxnStatus
import com.example.smartstock.data.TxnType
import com.example.smartstock.util.EthiopianCalendar
import com.example.smartstock.util.Formatters
import com.example.smartstock.util.NameNormalizer
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import kotlin.math.abs

enum class SalesLineAction {
    MATCHED,
    CREATE_NEW,
    IGNORE,
    UNRESOLVED
}

data class EditableCargoItem(
    val tempId: String,
    val rawName: String,
    val displayName: String,
    val qty: Int,
    val confidence: Confidence,
    val matchedItemId: String?,
    val createAsNew: Boolean = false
)

data class EditableSaleLine(
    val tempId: String,
    val rawText: String,
    val rawName: String,
    val displayName: String,
    val qty: Int,
    val unitPrice: Double?,
    val writtenLineTotal: Double?,
    val confidence: Confidence,
    val matchedItemId: String?,
    val action: SalesLineAction
) {
    val computedLineTotal: Double
        get() = if (action == SalesLineAction.IGNORE) 0.0 else (qty.coerceAtLeast(0) * (unitPrice ?: 0.0))
}

data class SaleLineWarnings(
    val aboveStockRemaining: Int? = null,
    val cataloguePriceForDiffWarning: Double? = null,
    val lineMathMismatch: Pair<Double, Double>? = null // computed vs written
)

data class StockApplyResult(
    val updatedItems: List<Item>,
    val stockClamped: Boolean
)

data class DaySalesBar(
    val date: LocalDate,
    val weekdayLabel: String,
    val totalEtb: Double
)

data class TopSeller(
    val name: String,
    val totalQty: Int,
    val totalEtb: Double
)

data class DashboardMetrics(
    val todaySalesEtb: Double,
    val todaySaleCount: Int,
    val todayEstimatedProfitEtb: Double?, // null if no line today had a known costPrice
    val lowStockCount: Int,
    val topSellersWeek: List<TopSeller>,
    val sevenDayBars: List<DaySalesBar>
)

object StockEngine {

    /**
     * Computes cargo comparison rows in Kotlin from sent and received items.
     */
    fun computeCargoDiff(
        sent: List<Pair<String, Int>>,
        received: List<Pair<String, Int>>
    ): List<CargoShortage> {
        if (sent.isEmpty()) return emptyList()

        data class Acc(var label: String, var sentQty: Int = 0, var receivedQty: Int = 0)
        val map = LinkedHashMap<String, Acc>()

        for ((name, qty) in sent) {
            val key = NameNormalizer.normalize(name).ifEmpty { name.trim() }
            val acc = map.getOrPut(key) { Acc(label = name.trim()) }
            acc.sentQty += qty.coerceAtLeast(0)
        }
        for ((name, qty) in received) {
            val key = NameNormalizer.normalize(name).ifEmpty { name.trim() }
            val acc = map.getOrPut(key) { Acc(label = name.trim()) }
            acc.receivedQty += qty.coerceAtLeast(0)
        }

        return map.values.map { acc ->
            CargoShortage(
                name = acc.label,
                sentQty = acc.sentQty,
                receivedQty = acc.receivedQty,
                diff = acc.receivedQty - acc.sentQty
            )
        }
    }

    /**
     * Computes total ETB for active (non-ignored) sale lines in Kotlin.
     */
    fun computeSalesTotal(lines: List<EditableSaleLine>): Double {
        return lines.sumOf { it.computedLineTotal }
    }

    /**
     * Checks whether all sale lines are resolved (matched, create new, or ignored) and at least one active line exists.
     */
    fun canConfirmSale(lines: List<EditableSaleLine>): Boolean {
        if (lines.isEmpty()) return false
        val hasUnresolved = lines.any { it.action == SalesLineAction.UNRESOLVED }
        val hasActiveLine = lines.any { it.action != SalesLineAction.IGNORE && it.qty > 0 }
        return !hasUnresolved && hasActiveLine
    }

    /**
     * Computes all per-line warnings in Kotlin:
     * - qty > stock (ቀሪ: N)
     * - unitPrice differs > 20% from catalogue sellPrice
     * - qty * unitPrice != writtenLineTotal (tolerance 0.5 ETB)
     */
    fun computeSaleLineWarnings(
        line: EditableSaleLine,
        catalogue: List<Item>
    ): SaleLineWarnings {
        if (line.action == SalesLineAction.IGNORE) return SaleLineWarnings()

        val matchedItem = line.matchedItemId?.let { id -> catalogue.firstOrNull { it.id == id } }

        val aboveStock = if (matchedItem != null && line.qty > matchedItem.qty) {
            matchedItem.qty
        } else {
            null
        }

        val priceDiffCatalog = if (matchedItem?.sellPrice != null && matchedItem.sellPrice > 0.0 && line.unitPrice != null) {
            val diffRatio = abs(line.unitPrice - matchedItem.sellPrice) / matchedItem.sellPrice
            if (diffRatio > 0.20) matchedItem.sellPrice else null
        } else {
            null
        }

        val mathMismatch = if (line.writtenLineTotal != null && line.unitPrice != null) {
            val computed = line.qty * line.unitPrice
            if (abs(computed - line.writtenLineTotal) > 0.5) {
                Pair(computed, line.writtenLineTotal)
            } else {
                null
            }
        } else {
            null
        }

        return SaleLineWarnings(
            aboveStockRemaining = aboveStock,
            cataloguePriceForDiffWarning = priceDiffCatalog,
            lineMathMismatch = mathMismatch
        )
    }

    /**
     * Checks if computed grand total differs from notebook's written grand total (tolerance 0.5 ETB).
     */
    fun hasGrandTotalMismatch(computedTotal: Double, writtenGrandTotal: Double?): Boolean {
        if (writtenGrandTotal == null) return false
        return abs(computedTotal - writtenGrandTotal) > 0.5
    }

    /**
     * Applies a STOCK_IN transaction to the catalogue:
     * - Increments matched item quantities
     * - Appends learned aliases if rawName differs from item name
     * - Creates new items if itemId is null
     */
    fun applyStockIn(
        currentItems: List<Item>,
        lines: List<Line>,
        learnedAliases: Map<String, String> = emptyMap(),
        defaultThreshold: Int = Item.DEFAULT_LOW_THRESHOLD
    ): List<Item> {
        val mutable = currentItems.toMutableList()
        for (line in lines) {
            if (line.qty <= 0) continue
            val idx = if (line.itemId != null) {
                mutable.indexOfFirst { it.id == line.itemId }
            } else {
                val norm = NameNormalizer.normalize(line.name)
                mutable.indexOfFirst { NameNormalizer.normalize(it.name) == norm }
            }

            if (idx >= 0) {
                val existing = mutable[idx]
                val rawAlias = learnedAliases[existing.id]?.trim()
                val updatedAliases = if (!rawAlias.isNullOrEmpty() &&
                    NameNormalizer.normalize(rawAlias) != NameNormalizer.normalize(existing.name) &&
                    existing.aliases.none { NameNormalizer.normalize(it) == NameNormalizer.normalize(rawAlias) }
                ) {
                    existing.aliases + rawAlias
                } else {
                    existing.aliases
                }
                mutable[idx] = existing.copy(
                    qty = (existing.qty + line.qty).coerceAtLeast(0),
                    aliases = updatedAliases
                )
            } else {
                mutable.add(
                    Item(
                        name = line.name.trim(),
                        unit = Item.DEFAULT_UNIT,
                        qty = line.qty.coerceAtLeast(0),
                        lowThreshold = defaultThreshold,
                        sellPrice = line.unitPrice
                    )
                )
            }
        }
        return mutable
    }

    /**
     * Applies a SALE transaction to the catalogue:
     * - Never allows stock to go below 0
     * - If sale qty > current stock, sets stock to 0 and marks stockClamped = true
     * - Records learned aliases if provided
     */
    fun applySale(
        currentItems: List<Item>,
        lines: List<Line>,
        learnedAliases: Map<String, String> = emptyMap()
    ): StockApplyResult {
        val mutable = currentItems.toMutableList()
        var clamped = false

        for (line in lines) {
            if (line.qty <= 0 || line.itemId == null) continue
            val idx = mutable.indexOfFirst { it.id == line.itemId }
            if (idx >= 0) {
                val existing = mutable[idx]
                val newQty = existing.qty - line.qty
                if (newQty < 0) {
                    clamped = true
                }
                val rawAlias = learnedAliases[existing.id]?.trim()
                val updatedAliases = if (!rawAlias.isNullOrEmpty() &&
                    NameNormalizer.normalize(rawAlias) != NameNormalizer.normalize(existing.name) &&
                    existing.aliases.none { NameNormalizer.normalize(it) == NameNormalizer.normalize(rawAlias) }
                ) {
                    existing.aliases + rawAlias
                } else {
                    existing.aliases
                }
                mutable[idx] = existing.copy(
                    qty = newQty.coerceAtLeast(0),
                    aliases = updatedAliases
                )
            }
        }
        return StockApplyResult(updatedItems = mutable, stockClamped = clamped)
    }

    /**
     * Reverses the stock effect of an ACTIVE transaction when voided (clamped at 0).
     * - Voiding a SALE adds quantities back to stock.
     * - Voiding a STOCK_IN subtracts quantities from stock (clamped at 0).
     */
    fun reverseTxnStockEffect(currentItems: List<Item>, txn: Txn): List<Item> {
        if (txn.status == TxnStatus.VOIDED) return currentItems
        val mutable = currentItems.toMutableList()
        for (line in txn.lines) {
            val idx = if (line.itemId != null) {
                mutable.indexOfFirst { it.id == line.itemId }
            } else {
                val norm = NameNormalizer.normalize(line.name)
                mutable.indexOfFirst { NameNormalizer.normalize(it.name) == norm }
            }
            if (idx >= 0) {
                val existing = mutable[idx]
                val updatedQty = when (txn.type) {
                    TxnType.SALE -> existing.qty + line.qty
                    TxnType.STOCK_IN -> (existing.qty - line.qty).coerceAtLeast(0)
                }
                mutable[idx] = existing.copy(qty = updatedQty.coerceAtLeast(0))
            }
        }
        return mutable
    }

    /**
     * Checks if any image hash already exists in an ACTIVE transaction.
     */
    fun isDuplicatePhoto(hashes: List<String>, history: List<Txn>): Boolean {
        if (hashes.isEmpty()) return false
        val activeHashes = history
            .filter { it.status == TxnStatus.ACTIVE }
            .flatMap { it.imageHashes }
            .toSet()
        return hashes.any { it in activeHashes }
    }

    /**
     * Computes today's total sales (ETB) across all ACTIVE SALE transactions.
     */
    fun todaySalesTotal(
        history: List<Txn>,
        today: LocalDate = LocalDate.now(),
        zoneId: ZoneId = ZoneId.systemDefault()
    ): Double {
        return history
            .filter {
                it.status == TxnStatus.ACTIVE &&
                    it.type == TxnType.SALE &&
                    Instant.ofEpochMilli(it.timestamp).atZone(zoneId).toLocalDate() == today
            }
            .sumOf { it.totalEtb }
    }

    /**
     * Computes full Dashboard metrics locally in Kotlin.
     */
    fun computeDashboardMetrics(
        items: List<Item>,
        history: List<Txn>,
        today: LocalDate = LocalDate.now(),
        zoneId: ZoneId = ZoneId.systemDefault()
    ): DashboardMetrics {
        val itemById = items.associateBy { it.id }
        val activeSales = history.filter { it.status == TxnStatus.ACTIVE && it.type == TxnType.SALE }

        val todaySales = activeSales.filter {
            Instant.ofEpochMilli(it.timestamp).atZone(zoneId).toLocalDate() == today
        }
        val todaySalesEtb = todaySales.sumOf { it.totalEtb }
        val todaySaleCount = todaySales.size

        // Estimated profit: only lines whose item has a costPrice
        var profitSum = 0.0
        var hasAnyCost = false
        for (txn in todaySales) {
            for (line in txn.lines) {
                val item = line.itemId?.let { itemById[it] }
                val cost = item?.costPrice
                val sell = line.unitPrice ?: item?.sellPrice
                if (cost != null && sell != null) {
                    profitSum += (sell - cost) * line.qty
                    hasAnyCost = true
                }
            }
        }
        val todayEstimatedProfit = if (hasAnyCost) profitSum else null

        val lowStockCount = items.count { it.qty < it.lowThreshold }

        // Top 3 sellers in the last 7 days
        val weekStart = today.minusDays(6)
        val weekSales = activeSales.filter {
            val d = Instant.ofEpochMilli(it.timestamp).atZone(zoneId).toLocalDate()
            !d.isBefore(weekStart) && !d.isAfter(today)
        }
        data class SellerAcc(val name: String, var qty: Int = 0, var revenue: Double = 0.0)
        val sellerMap = LinkedHashMap<String, SellerAcc>()
        for (txn in weekSales) {
            for (line in txn.lines) {
                val key = line.itemId ?: NameNormalizer.normalize(line.name)
                val acc = sellerMap.getOrPut(key) { SellerAcc(line.name) }
                acc.qty += line.qty
                acc.revenue += line.qty * (line.unitPrice ?: 0.0)
            }
        }
        val topSellers = sellerMap.values
            .sortedByDescending { it.qty }
            .take(3)
            .map { TopSeller(it.name, it.qty, it.revenue) }

        // 7-day sales bars (oldest to today)
        val salesByDay = weekSales.groupBy {
            Instant.ofEpochMilli(it.timestamp).atZone(zoneId).toLocalDate()
        }.mapValues { entry -> entry.value.sumOf { it.totalEtb } }

        val bars = (6 downTo 0).map { offset ->
            val d = today.minusDays(offset.toLong())
            DaySalesBar(
                date = d,
                weekdayLabel = EthiopianCalendar.weekdayShort(d),
                totalEtb = salesByDay[d] ?: 0.0
            )
        }

        return DashboardMetrics(
            todaySalesEtb = todaySalesEtb,
            todaySaleCount = todaySaleCount,
            todayEstimatedProfitEtb = todayEstimatedProfit,
            lowStockCount = lowStockCount,
            topSellersWeek = topSellers,
            sevenDayBars = bars
        )
    }

    /**
     * Builds compact 14-day sales + stock + days-of-cover text locally for Gemini weekly advice.
     */
    fun build14DayInsightsSummary(
        items: List<Item>,
        history: List<Txn>,
        today: LocalDate = LocalDate.now(),
        zoneId: ZoneId = ZoneId.systemDefault()
    ): String {
        val start14 = today.minusDays(13)
        val sales14 = history.filter {
            it.status == TxnStatus.ACTIVE &&
                it.type == TxnType.SALE &&
                !Instant.ofEpochMilli(it.timestamp).atZone(zoneId).toLocalDate().isBefore(start14)
        }
        val qtySoldByItem = mutableMapOf<String, Int>()
        for (txn in sales14) {
            for (line in txn.lines) {
                val key = line.itemId ?: NameNormalizer.normalize(line.name)
                qtySoldByItem[key] = (qtySoldByItem[key] ?: 0) + line.qty
            }
        }

        val sb = StringBuilder()
        sb.appendLine("14-day shop inventory summary (item | stock | threshold | sold_14d | days_of_cover):")
        for (item in items.take(150)) {
            val sold14 = qtySoldByItem[item.id] ?: qtySoldByItem[NameNormalizer.normalize(item.name)] ?: 0
            val dailyRate = sold14 / 14.0
            val daysOfCover = if (dailyRate > 0.0) String.format(java.util.Locale.US, "%.1f", item.qty / dailyRate) else "∞"
            sb.appendLine("- ${item.name} (${item.unit}): stock=${item.qty}, min=${item.lowThreshold}, sold14d=$sold14, coverDays=$daysOfCover")
        }
        val totalRev14 = sales14.sumOf { it.totalEtb }
        sb.appendLine("Total 14-day revenue: ${Formatters.formatMoney(totalRev14)} ETB across ${sales14.size} sales.")
        return sb.toString()
    }

    /**
     * Builds a UTF-8 with BOM CSV string of transaction history so Excel displays Amharic properly.
     */
    fun buildHistoryCsv(history: List<Txn>, useEthiopianDate: Boolean): String {
        val sb = StringBuilder()
        sb.append('\uFEFF') // UTF-8 BOM
        sb.appendLine("ቀን,ሰዓት,ዓይነት,ሁኔታ,እቃዎች,ጠቅላላ (ብር),ማስታወሻ")
        for (txn in history.sortedByDescending { it.timestamp }) {
            val dateStr = EthiopianCalendar.formatTimestampDate(txn.timestamp, useEthiopianDate)
            val timeStr = EthiopianCalendar.formatTimestampTime(txn.timestamp)
            val typeStr = if (txn.type == TxnType.SALE) "ሽያጭ" else "እቃ መቀበያ"
            val statusStr = if (txn.status == TxnStatus.ACTIVE) "ንቁ" else "ተሽሯል"
            val itemsSummary = txn.lines.joinToString("; ") { "${it.name} x${it.qty}" }
            val totalStr = if (txn.type == TxnType.SALE) Formatters.formatMoney(txn.totalEtb) else "0"
            val noteStr = txn.note ?: txn.reportAm ?: ""
            sb.appendLine(
                listOf(dateStr, timeStr, typeStr, statusStr, itemsSummary, totalStr, noteStr)
                    .joinToString(",") { csvEscape(it) }
            )
        }
        return sb.toString()
    }

    private fun csvEscape(raw: String): String {
        val clean = raw.replace("\r\n", " ").replace("\n", " ")
        return if (clean.contains(',') || clean.contains('"')) {
            "\"${clean.replace("\"", "\"\"")}\""
        } else {
            clean
        }
    }
}
