package com.example.smartstock.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.smartstock.R
import com.example.smartstock.ai.AiErrorType
import com.example.smartstock.ai.AiException
import com.example.smartstock.ai.AiProgressEvent
import com.example.smartstock.ai.GeminiClient
import com.example.smartstock.ai.ImageProcessor
import com.example.smartstock.ai.ProgressPhase
import com.example.smartstock.data.AppSettings
import com.example.smartstock.data.CargoShortage
import com.example.smartstock.data.Confidence
import com.example.smartstock.data.DateStyle
import com.example.smartstock.data.Item
import com.example.smartstock.data.JsonCodec
import com.example.smartstock.data.Line
import com.example.smartstock.data.SecureStore
import com.example.smartstock.data.SmartStockRepository
import com.example.smartstock.data.Txn
import com.example.smartstock.data.TxnStatus
import com.example.smartstock.data.TxnType
import com.example.smartstock.domain.DashboardMetrics
import com.example.smartstock.domain.EditableCargoItem
import com.example.smartstock.domain.EditableSaleLine
import com.example.smartstock.domain.SalesLineAction
import com.example.smartstock.domain.StockEngine
import com.example.smartstock.util.Formatters
import com.example.smartstock.util.NameNormalizer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.util.UUID

data class CargoUiState(
    val isAnalyzing: Boolean = false,
    val progressPercent: Int = 0,
    val progressStatus: String = "",
    val errorMessage: String? = null,
    val sentItemsRaw: List<Pair<String, Int>> = emptyList(),
    val receivedPreview: List<EditableCargoItem> = emptyList(),
    val reportAm: String = "",
    val photoNoteAm: String = "",
    val imageHashes: List<String> = emptyList(),
    val analyzedPhotoUris: List<Uri> = emptyList(),
    val isSubmitting: Boolean = false,
    val lastSavedShortages: List<CargoShortage> = emptyList(),
    val lastSavedReportAm: String = ""
) {
    val comparisonRows: List<CargoShortage>
        get() = StockEngine.computeCargoDiff(
            sent = sentItemsRaw,
            received = receivedPreview.map { it.displayName to it.qty }
        )
}

data class SalesUiState(
    val isAnalyzing: Boolean = false,
    val progressPercent: Int = 0,
    val progressStatus: String = "",
    val errorMessage: String? = null,
    val lines: List<EditableSaleLine> = emptyList(),
    val writtenGrandTotal: Double? = null,
    val notesAm: String = "",
    val imageHashes: List<String> = emptyList(),
    val analyzedPhotoUris: List<Uri> = emptyList(),
    val duplicatePhotoWarning: Boolean = false,
    val isSubmitting: Boolean = false,
    val confirmedTodayTotalEtb: Double? = null
)

data class AdviceUiState(
    val isLoading: Boolean = false,
    val suggestions: List<String> = emptyList(),
    val isCachedToday: Boolean = false,
    val errorMessage: String? = null
)

enum class KeyTestStatus {
    IDLE,
    TESTING,
    SUCCESS,
    FAILED
}

data class AppUiState(
    val items: List<Item> = emptyList(),
    val history: List<Txn> = emptyList(),
    val settings: AppSettings = AppSettings(),
    val dashboard: DashboardMetrics = StockEngine.computeDashboardMetrics(emptyList(), emptyList()),
    val hasApiKey: Boolean = false,
    val stockFilterLowOnly: Boolean = false,
    val cargo: CargoUiState = CargoUiState(),
    val sales: SalesUiState = SalesUiState(),
    val advice: AdviceUiState = AdviceUiState(),
    val keyTestStatus: KeyTestStatus = KeyTestStatus.IDLE,
    val keyTestMessage: String? = null,
    val snackbarMessage: String? = null
)

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext
    private val repository = SmartStockRepository(appContext)
    private val secureStore = SecureStore(appContext)
    private val geminiClient = GeminiClient()

    private val _uiState = MutableStateFlow(AppUiState())
    val uiState: StateFlow<AppUiState> = _uiState.asStateFlow()

    private var cargoJob: Job? = null
    private var salesJob: Job? = null
    private var adviceJob: Job? = null

    init {
        reloadAll()
    }

    private fun reloadAll() {
        val items = repository.loadItems()
        val history = repository.loadHistory()
        val settings = repository.loadSettings()
        val hasKey = !secureStore.getApiKey().isNullOrBlank()
        val todayKey = LocalDate.now().toString()
        val cachedAdvice = if (settings.cachedAdviceDate == todayKey && settings.cachedAdviceLines.isNotEmpty()) {
            AdviceUiState(
                suggestions = settings.cachedAdviceLines,
                isCachedToday = true
            )
        } else {
            AdviceUiState()
        }
        _uiState.update {
            it.copy(
                items = items,
                history = history,
                settings = settings,
                dashboard = StockEngine.computeDashboardMetrics(items, history),
                hasApiKey = hasKey,
                advice = cachedAdvice
            )
        }
    }

    fun evidenceFile(fileName: String): File = repository.evidenceFile(fileName)

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    fun showSnackbar(message: String) {
        _uiState.update { it.copy(snackbarMessage = message) }
    }

    fun setStockFilterLowOnly(lowOnly: Boolean) {
        _uiState.update { it.copy(stockFilterLowOnly = lowOnly) }
    }

    // ---- Privacy ----

    fun acceptPrivacy() {
        val updated = _uiState.value.settings.copy(privacyAccepted = true)
        repository.saveSettings(updated)
        _uiState.update { it.copy(settings = updated) }
    }

    // ---- Stock CRUD ----

    fun findDuplicateItemByName(name: String, excludeId: String? = null): Item? {
        val norm = NameNormalizer.normalize(name)
        if (norm.isEmpty()) return null
        return _uiState.value.items.firstOrNull { item ->
            item.id != excludeId && (
                NameNormalizer.normalize(item.name) == norm ||
                    item.aliases.any { NameNormalizer.normalize(it) == norm }
                )
        }
    }

    fun addItem(
        name: String,
        qty: Int,
        unit: String,
        sellPrice: Double?,
        costPrice: Double?
    ) {
        val threshold = _uiState.value.settings.defaultLowThreshold
        val newItem = Item(
            name = name.trim(),
            unit = unit.ifBlank { Item.DEFAULT_UNIT },
            qty = qty.coerceAtLeast(0),
            lowThreshold = threshold,
            sellPrice = sellPrice,
            costPrice = costPrice
        )
        val updated = _uiState.value.items + newItem
        persistItems(updated)
    }

    fun mergeQtyIntoExistingItem(itemId: String, addQty: Int) {
        val updated = _uiState.value.items.map { item ->
            if (item.id == itemId) {
                item.copy(qty = (item.qty + addQty).coerceAtLeast(0))
            } else {
                item
            }
        }
        persistItems(updated)
    }

    fun updateItem(updatedItem: Item) {
        val updated = _uiState.value.items.map { item ->
            if (item.id == updatedItem.id) {
                updatedItem.copy(qty = updatedItem.qty.coerceAtLeast(0))
            } else {
                item
            }
        }
        persistItems(updated)
    }

    fun adjustItemQty(itemId: String, delta: Int) {
        val updated = _uiState.value.items.map { item ->
            if (item.id == itemId) {
                item.copy(qty = (item.qty + delta).coerceAtLeast(0))
            } else {
                item
            }
        }
        persistItems(updated)
    }

    fun deleteItem(itemId: String) {
        val updated = _uiState.value.items.filterNot { it.id == itemId }
        persistItems(updated)
    }

    fun buildReorderShareText(): String? {
        val lowItems = _uiState.value.items
            .filter { it.qty < it.lowThreshold }
            .sortedBy { it.qty }
        if (lowItems.isEmpty()) return null
        val sb = StringBuilder()
        sb.appendLine(appContext.getString(R.string.stock_reorder_header))
        sb.appendLine()
        for (item in lowItems) {
            val target = (item.lowThreshold * 2).coerceAtLeast(item.lowThreshold + 2)
            val suggested = (target - item.qty).coerceAtLeast(1)
            sb.appendLine(
                appContext.getString(
                    R.string.stock_reorder_line,
                    item.name,
                    item.qty,
                    item.unit,
                    suggested
                )
            )
        }
        return sb.toString().trim()
    }

    private fun persistItems(items: List<Item>) {
        repository.saveItems(items)
        val history = _uiState.value.history
        _uiState.update {
            it.copy(
                items = items,
                dashboard = StockEngine.computeDashboardMetrics(items, history)
            )
        }
    }

    // ---- Cargo Analysis & Confirmation ----

    fun analyzeCargo(sentUri: Uri?, receivedUri: Uri) {
        if (cargoJob?.isActive == true) return
        val apiKey = secureStore.getApiKey()
        if (apiKey.isNullOrBlank()) {
            _uiState.update {
                it.copy(cargo = it.cargo.copy(errorMessage = appContext.getString(R.string.err_missing_api_key)))
            }
            return
        }

        cargoJob = viewModelScope.launch {
            val totalPhotos = if (sentUri != null) 2 else 1
            _uiState.update {
                it.copy(
                    cargo = CargoUiState(
                        isAnalyzing = true,
                        progressPercent = 2,
                        progressStatus = appContext.getString(R.string.progress_preparing, 1, totalPhotos)
                    )
                )
            }

            try {
                var preparedCount = 0
                val sentProcessed = if (sentUri != null) {
                    val img = ImageProcessor.prepareForAi(appContext, sentUri)
                    preparedCount++
                    _uiState.update {
                        it.copy(
                            cargo = it.cargo.copy(
                                progressPercent = (preparedCount * 25) / totalPhotos,
                                progressStatus = appContext.getString(R.string.progress_preparing, preparedCount, totalPhotos)
                            )
                        )
                    }
                    img
                } else {
                    null
                }

                val receivedProcessed = ImageProcessor.prepareForAi(appContext, receivedUri)
                preparedCount++
                _uiState.update {
                    it.copy(
                        cargo = it.cargo.copy(
                            progressPercent = 25,
                            progressStatus = appContext.getString(R.string.progress_uploading)
                        )
                    )
                }

                val catalogue = _uiState.value.items
                val model = _uiState.value.settings.activeModel
                val result = geminiClient.analyzeCargo(
                    apiKey = apiKey,
                    model = model,
                    catalogue = catalogue,
                    sentImage = sentProcessed,
                    receivedImage = receivedProcessed,
                    onModelResolved = { newModel -> persistResolvedModel(newModel) },
                    onProgress = { ev ->
                        _uiState.update {
                            it.copy(
                                cargo = it.cargo.copy(
                                    progressPercent = ev.percent,
                                    progressStatus = mapProgressEvent(ev)
                                )
                            )
                        }
                    }
                )

                val editableReceived = result.receivedItems.map { rec ->
                    val matched = NameNormalizer.matchItem(rec.name, rec.matchedStockId, catalogue)
                    EditableCargoItem(
                        tempId = UUID.randomUUID().toString(),
                        rawName = rec.name,
                        displayName = matched?.name ?: rec.name,
                        qty = rec.qty,
                        confidence = rec.confidence,
                        matchedItemId = matched?.id,
                        createAsNew = matched == null
                    )
                }

                val hashes = buildList {
                    if (sentProcessed != null) add(sentProcessed.sha256)
                    add(receivedProcessed.sha256)
                }
                val uris = buildList {
                    if (sentUri != null) add(sentUri)
                    add(receivedUri)
                }

                _uiState.update {
                    it.copy(
                        cargo = it.cargo.copy(
                            isAnalyzing = false,
                            progressPercent = 100,
                            progressStatus = appContext.getString(R.string.progress_done),
                            errorMessage = null,
                            sentItemsRaw = result.sentItems.map { s -> s.name to s.qty },
                            receivedPreview = editableReceived,
                            reportAm = result.reportAm,
                            photoNoteAm = result.photoNoteAm,
                            imageHashes = hashes,
                            analyzedPhotoUris = uris
                        )
                    )
                }
            } catch (ce: CancellationException) {
                _uiState.update {
                    it.copy(cargo = it.cargo.copy(isAnalyzing = false, progressPercent = 0, progressStatus = ""))
                }
                throw ce
            } catch (e: AiException) {
                _uiState.update {
                    it.copy(cargo = it.cargo.copy(isAnalyzing = false, errorMessage = mapAiError(e.errorType)))
                }
            } catch (_: Exception) {
                _uiState.update {
                    it.copy(cargo = it.cargo.copy(isAnalyzing = false, errorMessage = appContext.getString(R.string.err_image_failed)))
                }
            }
        }
    }

    fun cancelCargoAnalysis() {
        cargoJob?.cancel()
        cargoJob = null
        _uiState.update {
            it.copy(cargo = it.cargo.copy(isAnalyzing = false, progressPercent = 0, progressStatus = ""))
        }
    }

    fun dismissCargoError() {
        _uiState.update { it.copy(cargo = it.cargo.copy(errorMessage = null)) }
    }

    fun updateCargoItemQty(tempId: String, delta: Int) {
        _uiState.update { state ->
            val updated = state.cargo.receivedPreview.map { item ->
                if (item.tempId == tempId) item.copy(qty = (item.qty + delta).coerceAtLeast(0)) else item
            }
            state.copy(cargo = state.cargo.copy(receivedPreview = updated))
        }
    }

    fun removeCargoItem(tempId: String) {
        _uiState.update { state ->
            state.copy(
                cargo = state.cargo.copy(
                    receivedPreview = state.cargo.receivedPreview.filterNot { it.tempId == tempId }
                )
            )
        }
    }

    fun mapCargoItemToExisting(tempId: String, existingItem: Item) {
        _uiState.update { state ->
            val updated = state.cargo.receivedPreview.map { row ->
                if (row.tempId == tempId) {
                    row.copy(
                        matchedItemId = existingItem.id,
                        displayName = existingItem.name,
                        createAsNew = false
                    )
                } else {
                    row
                }
            }
            state.copy(cargo = state.cargo.copy(receivedPreview = updated))
        }
    }

    fun markCargoItemAsNew(tempId: String) {
        _uiState.update { state ->
            val updated = state.cargo.receivedPreview.map { row ->
                if (row.tempId == tempId) {
                    row.copy(matchedItemId = null, displayName = row.rawName, createAsNew = true)
                } else {
                    row
                }
            }
            state.copy(cargo = state.cargo.copy(receivedPreview = updated))
        }
    }

    fun addMissedCargoItem(name: String, qty: Int) {
        val catalogue = _uiState.value.items
        val matched = NameNormalizer.matchItem(name, null, catalogue)
        val newRow = EditableCargoItem(
            tempId = UUID.randomUUID().toString(),
            rawName = name.trim(),
            displayName = matched?.name ?: name.trim(),
            qty = qty.coerceAtLeast(1),
            confidence = Confidence.HIGH,
            matchedItemId = matched?.id,
            createAsNew = matched == null
        )
        _uiState.update { state ->
            state.copy(cargo = state.cargo.copy(receivedPreview = state.cargo.receivedPreview + newRow))
        }
    }

    fun confirmCargo(onSuccess: () -> Unit) {
        val currentCargo = _uiState.value.cargo
        if (currentCargo.isSubmitting || currentCargo.receivedPreview.isEmpty()) return

        _uiState.update { it.copy(cargo = it.cargo.copy(isSubmitting = true)) }
        viewModelScope.launch {
            try {
                val thumbFiles = currentCargo.analyzedPhotoUris.mapNotNull { uri ->
                    runCatching { ImageProcessor.saveEvidenceThumbnail(appContext, uri, repository.evidenceDir) }.getOrNull()
                }
                val activeRows = currentCargo.receivedPreview.filter { it.qty > 0 }
                val lines = activeRows.map { row ->
                    Line(
                        itemId = row.matchedItemId,
                        name = row.displayName,
                        qty = row.qty
                    )
                }
                val learnedAliases = activeRows
                    .filter { it.matchedItemId != null }
                    .associate { it.matchedItemId!! to it.rawName }

                val currentItems = _uiState.value.items
                val updatedItems = StockEngine.applyStockIn(
                    currentItems = currentItems,
                    lines = lines,
                    learnedAliases = learnedAliases,
                    defaultThreshold = _uiState.value.settings.defaultLowThreshold
                )

                // Resolve newly created item IDs onto the saved transaction lines so voiding restores accurately
                val resolvedLines = lines.map { line ->
                    if (line.itemId != null) {
                        line
                    } else {
                        val norm = NameNormalizer.normalize(line.name)
                        val created = updatedItems.firstOrNull { NameNormalizer.normalize(it.name) == norm }
                        line.copy(itemId = created?.id)
                    }
                }

                val shortages = currentCargo.comparisonRows
                val txn = Txn(
                    type = TxnType.STOCK_IN,
                    lines = resolvedLines,
                    shortages = shortages,
                    reportAm = currentCargo.reportAm.ifBlank { null },
                    photoFiles = thumbFiles,
                    imageHashes = currentCargo.imageHashes
                )
                val updatedHistory = listOf(txn) + _uiState.value.history
                withContext(Dispatchers.IO) {
                    repository.commitItemsAndHistory(updatedItems, updatedHistory)
                }

                _uiState.update {
                    it.copy(
                        items = updatedItems,
                        history = updatedHistory,
                        dashboard = StockEngine.computeDashboardMetrics(updatedItems, updatedHistory),
                        cargo = CargoUiState(
                            lastSavedShortages = shortages,
                            lastSavedReportAm = currentCargo.reportAm
                        ),
                        snackbarMessage = appContext.getString(R.string.cargo_saved_snackbar)
                    )
                }
                onSuccess()
            } catch (_: Exception) {
                _uiState.update {
                    it.copy(
                        cargo = it.cargo.copy(
                            isSubmitting = false,
                            errorMessage = appContext.getString(R.string.err_unknown)
                        )
                    )
                }
            }
        }
    }

    fun buildCargoShareReportText(): String {
        val cargo = _uiState.value.cargo
        val rows = if (cargo.comparisonRows.isNotEmpty()) cargo.comparisonRows else cargo.lastSavedShortages
        val report = cargo.reportAm.ifBlank { cargo.lastSavedReportAm }
        val sb = StringBuilder()
        sb.appendLine(appContext.getString(R.string.cargo_share_header))
        sb.appendLine()
        val diffs = rows.filter { it.diff != 0 }
        if (diffs.isNotEmpty()) {
            sb.appendLine(appContext.getString(R.string.cargo_share_shortages))
            for (d in diffs) {
                val diffLabel = if (d.diff < 0) {
                    appContext.getString(R.string.cargo_diff_short, -d.diff)
                } else {
                    appContext.getString(R.string.cargo_diff_extra, d.diff)
                }
                sb.appendLine("• ${d.name}: ${d.sentQty} → ${d.receivedQty} ($diffLabel)")
            }
            sb.appendLine()
        } else if (rows.isNotEmpty()) {
            sb.appendLine(appContext.getString(R.string.cargo_share_none))
            sb.appendLine()
        }
        if (report.isNotBlank()) {
            sb.appendLine(report)
        }
        return sb.toString().trim()
    }

    // ---- Sales Analysis & Confirmation ----

    fun analyzeSales(photoUris: List<Uri>) {
        if (salesJob?.isActive == true || photoUris.isEmpty()) return
        val apiKey = secureStore.getApiKey()
        if (apiKey.isNullOrBlank()) {
            _uiState.update {
                it.copy(sales = it.sales.copy(errorMessage = appContext.getString(R.string.err_missing_api_key)))
            }
            return
        }

        salesJob = viewModelScope.launch {
            val totalPhotos = photoUris.size
            _uiState.update {
                it.copy(
                    sales = SalesUiState(
                        isAnalyzing = true,
                        progressPercent = 2,
                        progressStatus = appContext.getString(R.string.progress_preparing, 1, totalPhotos)
                    )
                )
            }

            try {
                val processed = mutableListOf<com.example.smartstock.ai.ProcessedImage>()
                for ((idx, uri) in photoUris.withIndex()) {
                    val img = ImageProcessor.prepareForAi(appContext, uri)
                    processed.add(img)
                    val pct = (((idx + 1) * 25) / totalPhotos).coerceIn(1, 25)
                    _uiState.update {
                        it.copy(
                            sales = it.sales.copy(
                                progressPercent = pct,
                                progressStatus = appContext.getString(R.string.progress_preparing, idx + 1, totalPhotos)
                            )
                        )
                    }
                }

                val hashes = processed.map { it.sha256 }
                val isDup = StockEngine.isDuplicatePhoto(hashes, _uiState.value.history)

                val catalogue = _uiState.value.items
                val model = _uiState.value.settings.activeModel
                val result = geminiClient.analyzeSales(
                    apiKey = apiKey,
                    model = model,
                    catalogue = catalogue,
                    images = processed,
                    onModelResolved = { newModel -> persistResolvedModel(newModel) },
                    onProgress = { ev ->
                        _uiState.update {
                            it.copy(
                                sales = it.sales.copy(
                                    progressPercent = ev.percent,
                                    progressStatus = mapProgressEvent(ev)
                                )
                            )
                        }
                    }
                )

                val editableLines = result.lines.map { line ->
                    val matched = NameNormalizer.matchItem(line.name, line.matchedStockId, catalogue)
                    val resolvedPrice = line.unitPrice ?: matched?.sellPrice
                    EditableSaleLine(
                        tempId = UUID.randomUUID().toString(),
                        rawText = line.rawText,
                        rawName = line.name,
                        displayName = matched?.name ?: line.name,
                        qty = line.qty,
                        unitPrice = resolvedPrice,
                        writtenLineTotal = line.lineTotal,
                        confidence = line.confidence,
                        matchedItemId = matched?.id,
                        action = if (matched != null) SalesLineAction.MATCHED else SalesLineAction.UNRESOLVED
                    )
                }

                _uiState.update {
                    it.copy(
                        sales = it.sales.copy(
                            isAnalyzing = false,
                            progressPercent = 100,
                            progressStatus = appContext.getString(R.string.progress_done),
                            errorMessage = null,
                            lines = editableLines,
                            writtenGrandTotal = result.writtenGrandTotal,
                            notesAm = result.notesAm,
                            imageHashes = hashes,
                            analyzedPhotoUris = photoUris,
                            duplicatePhotoWarning = isDup
                        )
                    )
                }
            } catch (ce: CancellationException) {
                _uiState.update {
                    it.copy(sales = it.sales.copy(isAnalyzing = false, progressPercent = 0, progressStatus = ""))
                }
                throw ce
            } catch (e: AiException) {
                _uiState.update {
                    it.copy(sales = it.sales.copy(isAnalyzing = false, errorMessage = mapAiError(e.errorType)))
                }
            } catch (_: Exception) {
                _uiState.update {
                    it.copy(sales = it.sales.copy(isAnalyzing = false, errorMessage = appContext.getString(R.string.err_image_failed)))
                }
            }
        }
    }

    fun cancelSalesAnalysis() {
        salesJob?.cancel()
        salesJob = null
        _uiState.update {
            it.copy(sales = it.sales.copy(isAnalyzing = false, progressPercent = 0, progressStatus = ""))
        }
    }

    fun dismissSalesError() {
        _uiState.update { it.copy(sales = it.sales.copy(errorMessage = null)) }
    }

    fun updateSaleLineQty(tempId: String, delta: Int) {
        _uiState.update { state ->
            val updated = state.sales.lines.map { l ->
                if (l.tempId == tempId) l.copy(qty = (l.qty + delta).coerceAtLeast(0)) else l
            }
            state.copy(sales = state.sales.copy(lines = updated))
        }
    }

    fun updateSaleLinePrice(tempId: String, price: Double?) {
        _uiState.update { state ->
            val updated = state.sales.lines.map { l ->
                if (l.tempId == tempId) l.copy(unitPrice = price) else l
            }
            state.copy(sales = state.sales.copy(lines = updated))
        }
    }

    fun removeSaleLine(tempId: String) {
        _uiState.update { state ->
            state.copy(sales = state.sales.copy(lines = state.sales.lines.filterNot { it.tempId == tempId }))
        }
    }

    fun mapSaleLineToExisting(tempId: String, existing: Item) {
        _uiState.update { state ->
            val updated = state.sales.lines.map { l ->
                if (l.tempId == tempId) {
                    l.copy(
                        matchedItemId = existing.id,
                        displayName = existing.name,
                        unitPrice = l.unitPrice ?: existing.sellPrice,
                        action = SalesLineAction.MATCHED
                    )
                } else {
                    l
                }
            }
            state.copy(sales = state.sales.copy(lines = updated))
        }
    }

    fun setSaleLineAction(tempId: String, action: SalesLineAction) {
        _uiState.update { state ->
            val updated = state.sales.lines.map { l ->
                if (l.tempId == tempId) {
                    l.copy(
                        matchedItemId = if (action == SalesLineAction.MATCHED) l.matchedItemId else null,
                        action = action
                    )
                } else {
                    l
                }
            }
            state.copy(sales = state.sales.copy(lines = updated))
        }
    }

    fun addManualSaleLine(name: String, qty: Int, unitPrice: Double?) {
        val catalogue = _uiState.value.items
        val matched = NameNormalizer.matchItem(name, null, catalogue)
        val line = EditableSaleLine(
            tempId = UUID.randomUUID().toString(),
            rawText = name.trim(),
            rawName = name.trim(),
            displayName = matched?.name ?: name.trim(),
            qty = qty.coerceAtLeast(1),
            unitPrice = unitPrice ?: matched?.sellPrice,
            writtenLineTotal = null,
            confidence = Confidence.HIGH,
            matchedItemId = matched?.id,
            action = if (matched != null) SalesLineAction.MATCHED else SalesLineAction.CREATE_NEW
        )
        _uiState.update { state ->
            state.copy(sales = state.sales.copy(lines = state.sales.lines + line))
        }
    }

    fun confirmSale(onSuccess: () -> Unit) {
        val currentSales = _uiState.value.sales
        if (currentSales.isSubmitting || !StockEngine.canConfirmSale(currentSales.lines)) return

        _uiState.update { it.copy(sales = it.sales.copy(isSubmitting = true)) }
        viewModelScope.launch {
            try {
                val thumbFiles = currentSales.analyzedPhotoUris.mapNotNull { uri ->
                    runCatching { ImageProcessor.saveEvidenceThumbnail(appContext, uri, repository.evidenceDir) }.getOrNull()
                }

                val currentItems = _uiState.value.items.toMutableList()
                val activeEditable = currentSales.lines.filter {
                    it.action != SalesLineAction.IGNORE && it.qty > 0
                }

                // Create any new items explicitly marked CREATE_NEW (starts at 0 since sold out)
                val finalLines = mutableListOf<Line>()
                val learnedAliases = mutableMapOf<String, String>()
                for (row in activeEditable) {
                    if (row.action == SalesLineAction.CREATE_NEW) {
                        val existing = currentItems.firstOrNull {
                            NameNormalizer.normalize(it.name) == NameNormalizer.normalize(row.displayName)
                        }
                        val itemId = if (existing != null) {
                            existing.id
                        } else {
                            val created = Item(
                                name = row.displayName.trim(),
                                unit = Item.DEFAULT_UNIT,
                                qty = 0,
                                lowThreshold = _uiState.value.settings.defaultLowThreshold,
                                sellPrice = row.unitPrice
                            )
                            currentItems.add(created)
                            created.id
                        }
                        finalLines.add(Line(itemId = itemId, name = row.displayName, qty = row.qty, unitPrice = row.unitPrice))
                    } else {
                        val id = row.matchedItemId
                        if (id != null) {
                            learnedAliases[id] = row.rawName
                        }
                        finalLines.add(Line(itemId = id, name = row.displayName, qty = row.qty, unitPrice = row.unitPrice))
                    }
                }

                val applyResult = StockEngine.applySale(
                    currentItems = currentItems,
                    lines = finalLines,
                    learnedAliases = learnedAliases
                )

                val totalEtb = StockEngine.computeSalesTotal(currentSales.lines)
                val note = if (applyResult.stockClamped) {
                    appContext.getString(R.string.sales_stock_clamped_note)
                } else {
                    currentSales.notesAm.ifBlank { null }
                }

                val txn = Txn(
                    type = TxnType.SALE,
                    lines = finalLines,
                    totalEtb = totalEtb,
                    photoFiles = thumbFiles,
                    imageHashes = currentSales.imageHashes,
                    note = note
                )

                val updatedHistory = listOf(txn) + _uiState.value.history
                withContext(Dispatchers.IO) {
                    repository.commitItemsAndHistory(applyResult.updatedItems, updatedHistory)
                }

                val todayTotal = StockEngine.todaySalesTotal(updatedHistory)
                _uiState.update {
                    it.copy(
                        items = applyResult.updatedItems,
                        history = updatedHistory,
                        dashboard = StockEngine.computeDashboardMetrics(applyResult.updatedItems, updatedHistory),
                        sales = SalesUiState(confirmedTodayTotalEtb = todayTotal),
                        snackbarMessage = appContext.getString(
                            R.string.sales_confirmed_banner,
                            Formatters.formatMoney(todayTotal)
                        )
                    )
                }
                onSuccess()
            } catch (_: Exception) {
                _uiState.update {
                    it.copy(
                        sales = it.sales.copy(
                            isSubmitting = false,
                            errorMessage = appContext.getString(R.string.err_unknown)
                        )
                    )
                }
            }
        }
    }

    // ---- History Void & CSV ----

    fun voidTransaction(txnId: String) {
        val history = _uiState.value.history
        val target = history.firstOrNull { it.id == txnId } ?: return
        if (target.status == TxnStatus.VOIDED) return

        val restoredItems = StockEngine.reverseTxnStockEffect(_uiState.value.items, target)
        val updatedHistory = history.map { txn ->
            if (txn.id == txnId) {
                txn.copy(status = TxnStatus.VOIDED, voidedAt = System.currentTimeMillis())
            } else {
                txn
            }
        }
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.commitItemsAndHistory(restoredItems, updatedHistory)
            }
            _uiState.update {
                it.copy(
                    items = restoredItems,
                    history = updatedHistory,
                    dashboard = StockEngine.computeDashboardMetrics(restoredItems, updatedHistory)
                )
            }
        }
    }

    fun exportHistoryCsvToUri(uri: Uri) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val useEth = _uiState.value.settings.dateStyle == DateStyle.ETHIOPIAN
                    val csv = StockEngine.buildHistoryCsv(_uiState.value.history, useEth)
                    appContext.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(csv.toByteArray(Charsets.UTF_8))
                        out.flush()
                    }
                    true
                } catch (_: Exception) {
                    false
                }
            }
            showSnackbar(
                appContext.getString(if (ok) R.string.history_csv_exported else R.string.history_csv_failed)
            )
        }
    }

    // ---- Weekly Advice (Dashboard) ----

    fun fetchWeeklyAdvice(forceRefresh: Boolean = false) {
        if (adviceJob?.isActive == true) return
        val todayKey = LocalDate.now().toString()
        val settings = _uiState.value.settings
        if (!forceRefresh && settings.cachedAdviceDate == todayKey && settings.cachedAdviceLines.isNotEmpty()) {
            _uiState.update {
                it.copy(
                    advice = AdviceUiState(
                        suggestions = settings.cachedAdviceLines,
                        isCachedToday = true
                    )
                )
            }
            return
        }

        val apiKey = secureStore.getApiKey()
        if (apiKey.isNullOrBlank()) {
            _uiState.update {
                it.copy(advice = it.advice.copy(errorMessage = appContext.getString(R.string.err_missing_api_key)))
            }
            return
        }

        adviceJob = viewModelScope.launch {
            _uiState.update { it.copy(advice = it.advice.copy(isLoading = true, errorMessage = null)) }
            try {
                val summary = StockEngine.build14DayInsightsSummary(_uiState.value.items, _uiState.value.history)
                val suggestions = geminiClient.fetchWeeklyAdvice(
                    apiKey = apiKey,
                    model = _uiState.value.settings.activeModel,
                    summaryText = summary,
                    onModelResolved = { newModel -> persistResolvedModel(newModel) }
                )
                val updatedSettings = _uiState.value.settings.copy(
                    cachedAdviceDate = todayKey,
                    cachedAdviceLines = suggestions
                )
                repository.saveSettings(updatedSettings)
                _uiState.update {
                    it.copy(
                        settings = updatedSettings,
                        advice = AdviceUiState(
                            isLoading = false,
                            suggestions = suggestions,
                            isCachedToday = true,
                            errorMessage = null
                        )
                    )
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (e: AiException) {
                _uiState.update {
                    it.copy(advice = it.advice.copy(isLoading = false, errorMessage = mapAiError(e.errorType)))
                }
            } catch (_: Exception) {
                _uiState.update {
                    it.copy(advice = it.advice.copy(isLoading = false, errorMessage = appContext.getString(R.string.err_unknown)))
                }
            }
        }
    }

    // ---- Settings, Backup & Restore ----

    fun loadStoredApiKey(): String = secureStore.getApiKey().orEmpty()

    fun saveApiKey(rawKey: String) {
        secureStore.saveApiKey(rawKey)
        val hasKey = !secureStore.getApiKey().isNullOrBlank()
        _uiState.update {
            it.copy(
                hasApiKey = hasKey,
                keyTestStatus = KeyTestStatus.IDLE,
                keyTestMessage = null,
                snackbarMessage = appContext.getString(R.string.settings_key_saved)
            )
        }
    }

    fun testApiKey(candidateKey: String) {
        val keyToTest = candidateKey.trim().ifBlank { secureStore.getApiKey().orEmpty() }
        if (keyToTest.isBlank()) {
            _uiState.update {
                it.copy(
                    keyTestStatus = KeyTestStatus.FAILED,
                    keyTestMessage = appContext.getString(R.string.err_missing_api_key)
                )
            }
            return
        }
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    keyTestStatus = KeyTestStatus.TESTING,
                    keyTestMessage = appContext.getString(R.string.settings_key_testing)
                )
            }
            try {
                geminiClient.testApiKey(
                    apiKey = keyToTest,
                    model = _uiState.value.settings.activeModel,
                    onModelResolved = { newModel -> persistResolvedModel(newModel) }
                )
                _uiState.update {
                    it.copy(
                        keyTestStatus = KeyTestStatus.SUCCESS,
                        keyTestMessage = appContext.getString(R.string.settings_key_valid)
                    )
                }
            } catch (e: AiException) {
                _uiState.update {
                    it.copy(
                        keyTestStatus = KeyTestStatus.FAILED,
                        keyTestMessage = mapAiError(e.errorType)
                    )
                }
            } catch (_: Exception) {
                _uiState.update {
                    it.copy(
                        keyTestStatus = KeyTestStatus.FAILED,
                        keyTestMessage = appContext.getString(R.string.err_unknown)
                    )
                }
            }
        }
    }

    fun resetModelToDefault() {
        val updated = _uiState.value.settings.copy(activeModel = AppSettings.DEFAULT_MODEL)
        repository.saveSettings(updated)
        _uiState.update {
            it.copy(
                settings = updated,
                snackbarMessage = appContext.getString(R.string.settings_model_reset_done)
            )
        }
    }

    fun updateDefaultLowThreshold(threshold: Int) {
        val safe = threshold.coerceIn(1, 999)
        val updated = _uiState.value.settings.copy(defaultLowThreshold = safe)
        repository.saveSettings(updated)
        _uiState.update { it.copy(settings = updated) }
    }

    fun updateDateStyle(style: DateStyle) {
        val updated = _uiState.value.settings.copy(dateStyle = style)
        repository.saveSettings(updated)
        _uiState.update { it.copy(settings = updated) }
    }

    fun exportBackupToUri(uri: Uri) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val state = _uiState.value
                    val json = repository.exportBackupJson(state.items, state.settings, state.history)
                    appContext.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(json.toByteArray(Charsets.UTF_8))
                        out.flush()
                    }
                    true
                } catch (_: Exception) {
                    false
                }
            }
            showSnackbar(
                appContext.getString(if (ok) R.string.settings_backup_saved else R.string.settings_backup_failed)
            )
        }
    }

    fun restoreBackupFromUri(uri: Uri) {
        viewModelScope.launch {
            val payload = withContext(Dispatchers.IO) {
                try {
                    val content = appContext.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use {
                        it.readText()
                    }
                    JsonCodec.decodeBackup(content)
                } catch (_: Exception) {
                    null
                }
            }
            if (payload == null) {
                showSnackbar(appContext.getString(R.string.settings_restore_invalid))
                return@launch
            }
            withContext(Dispatchers.IO) {
                repository.restoreFromBackup(payload)
            }
            reloadAll()
            showSnackbar(appContext.getString(R.string.settings_restore_success))
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                repository.clearAllData()
            }
            val clearedSettings = _uiState.value.settings.copy(
                cachedAdviceDate = null,
                cachedAdviceLines = emptyList()
            )
            repository.saveSettings(clearedSettings)
            _uiState.update {
                it.copy(
                    items = emptyList(),
                    history = emptyList(),
                    settings = clearedSettings,
                    dashboard = StockEngine.computeDashboardMetrics(emptyList(), emptyList()),
                    cargo = CargoUiState(),
                    sales = SalesUiState(),
                    advice = AdviceUiState(),
                    snackbarMessage = appContext.getString(R.string.settings_clear_done)
                )
            }
        }
    }

    private fun persistResolvedModel(model: String) {
        val updated = _uiState.value.settings.copy(activeModel = model)
        repository.saveSettings(updated)
        _uiState.update { it.copy(settings = updated) }
    }

    private fun mapProgressEvent(ev: AiProgressEvent): String {
        return when (ev.phase) {
            ProgressPhase.PREPARING -> appContext.getString(R.string.progress_preparing, 1, 1)
            ProgressPhase.UPLOADING -> appContext.getString(R.string.progress_uploading)
            ProgressPhase.ANALYZING -> appContext.getString(R.string.progress_analyzing)
            ProgressPhase.RETRYING -> appContext.getString(R.string.progress_retrying, ev.retryAttempt)
            ProgressPhase.RESOLVING_MODEL -> appContext.getString(R.string.progress_resolving_model)
            ProgressPhase.FIXING_JSON -> appContext.getString(R.string.progress_fixing_json)
            ProgressPhase.DONE -> appContext.getString(R.string.progress_done)
        }
    }

    private fun mapAiError(type: AiErrorType): String {
        val resId = when (type) {
            AiErrorType.MISSING_KEY -> R.string.err_missing_api_key
            AiErrorType.INVALID_KEY -> R.string.err_invalid_api_key
            AiErrorType.BAD_REQUEST -> R.string.err_bad_request
            AiErrorType.NO_INTERNET -> R.string.err_no_internet
            AiErrorType.TIMEOUT -> R.string.err_timeout
            AiErrorType.BLOCKED_CONTENT -> R.string.err_blocked_content
            AiErrorType.EMPTY_ANSWER -> R.string.err_empty_answer
            AiErrorType.MAX_TOKENS -> R.string.err_max_tokens
            AiErrorType.NO_MODEL_FOUND -> R.string.err_no_model_found
            AiErrorType.SERVER_BUSY -> R.string.err_server_busy
            AiErrorType.PARSE_FAILED -> R.string.err_parse_failed
            AiErrorType.IMAGE_FAILED -> R.string.err_image_failed
            AiErrorType.UNKNOWN -> R.string.err_unknown
        }
        return appContext.getString(resId)
    }
}
