package com.example.smartstock.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.util.Base64
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.UUID
import kotlin.math.max

data class ProcessedImage(
    val jpegBytes: ByteArray,
    val base64: String,
    val sha256: String
)

object ImageProcessor {

    private const val AI_MAX_DIMENSION = 1280
    private const val AI_JPEG_QUALITY = 75
    private const val THUMB_MAX_DIMENSION = 320
    private const val THUMB_JPEG_QUALITY = 70

    fun createCameraPhotoUri(context: Context): Uri {
        val cameraDir = File(context.cacheDir, "camera").apply { mkdirs() }
        val file = File(cameraDir, "cap_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.jpg")
        return FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    }

    suspend fun prepareForAi(context: Context, uri: Uri): ProcessedImage = withContext(Dispatchers.Default) {
        val bytes = decodeRotateScaleCompress(
            context = context,
            uri = uri,
            maxDimension = AI_MAX_DIMENSION,
            jpegQuality = AI_JPEG_QUALITY
        )
        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val hash = sha256Hex(bytes)
        ProcessedImage(jpegBytes = bytes, base64 = b64, sha256 = hash)
    }

    suspend fun saveEvidenceThumbnail(context: Context, uri: Uri, evidenceDir: File): String = withContext(Dispatchers.Default) {
        evidenceDir.mkdirs()
        val bytes = decodeRotateScaleCompress(
            context = context,
            uri = uri,
            maxDimension = THUMB_MAX_DIMENSION,
            jpegQuality = THUMB_JPEG_QUALITY
        )
        val fileName = "ev_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.jpg"
        val outFile = File(evidenceDir, fileName)
        FileOutputStream(outFile).use { it.write(bytes) }
        fileName
    }

    suspend fun decodeThumbnailBitmap(context: Context, uri: Uri, maxDim: Int = 320): Bitmap? = withContext(Dispatchers.Default) {
        try {
            val bytes = decodeRotateScaleCompress(context, uri, maxDim, 75)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Exception) {
            null
        }
    }

    suspend fun decodeFileBitmap(file: File): Bitmap? = withContext(Dispatchers.Default) {
        try {
            if (!file.exists()) return@withContext null
            BitmapFactory.decodeFile(file.absolutePath)
        } catch (_: Exception) {
            null
        }
    }

    private fun decodeRotateScaleCompress(
        context: Context,
        uri: Uri,
        maxDimension: Int,
        jpegQuality: Int
    ): ByteArray {
        val resolver = context.contentResolver

        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val boundsStream = resolver.openInputStream(uri)
            ?: throw IllegalStateException("Cannot open image stream")
        boundsStream.use { stream ->
            BitmapFactory.decodeStream(stream, null, boundsOpts)
        }

        val rawW = boundsOpts.outWidth
        val rawH = boundsOpts.outHeight

        val rotated: Bitmap = if (rawW > 0 && rawH > 0) {
            var sampleSize = 1
            while (max(rawW / sampleSize, rawH / sampleSize) > maxDimension * 2) {
                sampleSize *= 2
            }

            val decodeOpts = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val decodeStream = resolver.openInputStream(uri)
                ?: throw IllegalStateException("Cannot open image stream for decode")
            val decoded = decodeStream.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOpts)
            } ?: throw IllegalStateException("Failed to decode image")

            val rotationDegrees = readExifRotationDegrees(context, uri)
            if (rotationDegrees != 0f) {
                val matrix = Matrix().apply { postRotate(rotationDegrees) }
                val r = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
                if (r != decoded) decoded.recycle()
                r
            } else {
                decoded
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            // Fallback for HEIC/HEIF/AVIF formats on Android 9+
            val source = ImageDecoder.createSource(resolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val longest = max(info.size.width, info.size.height)
                if (longest > maxDimension) {
                    val scale = maxDimension.toFloat() / longest.toFloat()
                    decoder.setTargetSize(
                        (info.size.width * scale).toInt().coerceAtLeast(1),
                        (info.size.height * scale).toInt().coerceAtLeast(1)
                    )
                }
            }
        } else {
            throw IllegalStateException("Invalid image dimensions")
        }

        val longest = max(rotated.width, rotated.height)
        val scaled = if (longest > maxDimension) {
            val scale = maxDimension.toFloat() / longest.toFloat()
            val targetW = (rotated.width * scale).toInt().coerceAtLeast(1)
            val targetH = (rotated.height * scale).toInt().coerceAtLeast(1)
            val s = Bitmap.createScaledBitmap(rotated, targetW, targetH, true)
            if (s != rotated) rotated.recycle()
            s
        } else {
            rotated
        }

        return try {
            val baos = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, jpegQuality, baos)
            baos.toByteArray()
        } finally {
            if (!scaled.isRecycled) scaled.recycle()
        }
    }

    private fun readExifRotationDegrees(context: Context, uri: Uri): Float {
        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val exif = ExifInterface(stream)
                when (exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                    ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                    ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                    else -> 0f
                }
            } ?: 0f
        } catch (_: Exception) {
            0f
        }
    }

    fun sha256Hex(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        val sb = StringBuilder(digest.size * 2)
        for (b in digest) {
            sb.append(String.format("%02x", b))
        }
        return sb.toString()
    }
}
