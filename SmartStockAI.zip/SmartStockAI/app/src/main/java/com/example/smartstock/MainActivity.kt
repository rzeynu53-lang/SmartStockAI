package com.example.smartstock

import android.content.res.Configuration
import android.os.Bundle
import android.os.LocaleList
import java.util.Locale
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.smartstock.data.AppLanguage
import com.example.smartstock.ui.AppViewModel
import com.example.smartstock.ui.screens.CargoScreen
import com.example.smartstock.ui.screens.DashboardScreen
import com.example.smartstock.ui.screens.HistoryScreen
import com.example.smartstock.ui.screens.SalesScreen
import com.example.smartstock.ui.screens.SettingsScreen
import com.example.smartstock.ui.screens.StockScreen
import com.example.smartstock.ui.theme.SmartStockTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SmartStockTheme {
                SmartStockApp()
            }
        }
    }
}

private data class NavTab(
    val labelRes: Int,
    val icon: ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SmartStockApp(viewModel: AppViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var selectedTab by rememberSaveable { mutableIntStateOf(0) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.snackbarMessage) {
        val msg = state.snackbarMessage
        if (msg != null) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    val baseContext = LocalContext.current
    val localizedContext = remember(state.settings.language, baseContext) {
        val locale = if (state.settings.language == AppLanguage.ENGLISH) Locale("en") else Locale("am")
        val config = Configuration(baseContext.resources.configuration)
        config.setLocales(LocaleList(locale))
        baseContext.createConfigurationContext(config)
    }

    CompositionLocalProvider(LocalContext provides localizedContext) {
    val tabs = remember {
        listOf(
            NavTab(R.string.nav_dashboard, Icons.Default.Home),
            NavTab(R.string.nav_stock, Icons.Default.List),
            NavTab(R.string.nav_cargo, Icons.Default.Add),
            NavTab(R.string.nav_sales, Icons.Default.ShoppingCart),
            NavTab(R.string.nav_history, Icons.Default.DateRange)
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = stringResource(
                            if (showSettings) R.string.nav_settings else R.string.app_name
                        )
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                ),
                navigationIcon = {
                    if (showSettings) {
                        IconButton(onClick = { showSettings = false }) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = stringResource(R.string.action_back)
                            )
                        }
                    }
                },
                actions = {
                    if (!showSettings) {
                        IconButton(onClick = { showSettings = true }) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = stringResource(R.string.nav_settings)
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (!showSettings) {
                NavigationBar {
                    tabs.forEachIndexed { index, tab ->
                        NavigationBarItem(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            icon = { Icon(tab.icon, contentDescription = stringResource(tab.labelRes)) },
                            label = {
                                Text(
                                    text = stringResource(tab.labelRes),
                                    maxLines = 1
                                )
                            }
                        )
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (showSettings) {
                SettingsScreen(
                    state = state,
                    initialApiKey = remember { viewModel.loadStoredApiKey() },
                    onSaveApiKey = viewModel::saveApiKey,
                    onTestApiKey = viewModel::testApiKey,
                    onSelectModel = viewModel::selectModel,
                    onResetModel = viewModel::resetModelToDefault,
                    onUpdateThreshold = viewModel::updateDefaultLowThreshold,
                    onUpdateLanguage = viewModel::updateLanguage,
                    onUpdateDateStyle = viewModel::updateDateStyle,
                    onBackupToUri = viewModel::exportBackupToUri,
                    onRestoreFromUri = viewModel::restoreBackupFromUri,
                    onClearAllData = viewModel::clearAllData
                )
            } else {
                when (selectedTab) {
                    0 -> DashboardScreen(
                        state = state,
                        onOpenLowStock = {
                            viewModel.setStockFilterLowOnly(true)
                            selectedTab = 1
                        },
                        onOpenSales = { selectedTab = 3 },
                        onOpenCargo = { selectedTab = 2 },
                        onFetchAdvice = viewModel::fetchWeeklyAdvice
                    )
                    1 -> StockScreen(
                        state = state,
                        onToggleLowFilter = viewModel::setStockFilterLowOnly,
                        onFindDuplicate = viewModel::findDuplicateItemByName,
                        onAddItem = viewModel::addItem,
                        onMergeQty = viewModel::mergeQtyIntoExistingItem,
                        onUpdateItem = viewModel::updateItem,
                        onAdjustQty = viewModel::adjustItemQty,
                        onDeleteItem = viewModel::deleteItem,
                        onBuildReorderText = viewModel::buildReorderShareText,
                        onShowMessage = viewModel::showSnackbar
                    )
                    2 -> CargoScreen(
                        state = state,
                        onAnalyze = viewModel::analyzeCargo,
                        onCancelAnalyze = viewModel::cancelCargoAnalysis,
                        onDismissError = viewModel::dismissCargoError,
                        onUpdateQty = viewModel::updateCargoItemQty,
                        onRemoveItem = viewModel::removeCargoItem,
                        onMapToExisting = viewModel::mapCargoItemToExisting,
                        onMarkAsNew = viewModel::markCargoItemAsNew,
                        onAddMissedItem = viewModel::addMissedCargoItem,
                        onConfirm = viewModel::confirmCargo,
                        onBuildShareReport = viewModel::buildCargoShareReportText,
                        onShowMessage = viewModel::showSnackbar
                    )
                    3 -> SalesScreen(
                        state = state,
                        onAnalyze = viewModel::analyzeSales,
                        onCancelAnalyze = viewModel::cancelSalesAnalysis,
                        onDismissError = viewModel::dismissSalesError,
                        onUpdateQty = viewModel::updateSaleLineQty,
                        onUpdatePrice = viewModel::updateSaleLinePrice,
                        onRemoveLine = viewModel::removeSaleLine,
                        onMapToExisting = viewModel::mapSaleLineToExisting,
                        onSetAction = viewModel::setSaleLineAction,
                        onAddManualLine = viewModel::addManualSaleLine,
                        onConfirmSale = viewModel::confirmSale,
                        onShowMessage = viewModel::showSnackbar
                    )
                    4 -> HistoryScreen(
                        state = state,
                        evidenceFileProvider = viewModel::evidenceFile,
                        onVoidTxn = viewModel::voidTransaction,
                        onExportCsv = viewModel::exportHistoryCsvToUri
                    )
                }
            }
        }
    }

    // First-launch privacy dialog
    if (!state.settings.privacyAccepted) {
        AlertDialog(
            onDismissRequest = {},
            title = { Text(stringResource(R.string.privacy_title)) },
            text = { Text(stringResource(R.string.privacy_body)) },
            confirmButton = {
                Button(onClick = viewModel::acceptPrivacy) {
                    Text(stringResource(R.string.privacy_accept))
                }
            }
        )
    }
    }
}
