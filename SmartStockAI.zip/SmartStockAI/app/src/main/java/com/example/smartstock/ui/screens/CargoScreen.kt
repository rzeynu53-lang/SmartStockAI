package com.example.smartstock.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.smartstock.R
import com.example.smartstock.ai.ImageProcessor
import com.example.smartstock.data.CargoShortage
import com.example.smartstock.data.Confidence
import com.example.smartstock.data.Item
import com.example.smartstock.domain.EditableCargoItem
import com.example.smartstock.ui.AppUiState
import com.example.smartstock.ui.components.AiProgressCard
import com.example.smartstock.ui.components.ConfidenceChip
import com.example.smartstock.ui.components.EmptyStateCard
import com.example.smartstock.ui.components.ErrorBanner
import com.example.smartstock.ui.components.StatusBadge
import com.example.smartstock.ui.components.UriThumbnail
import com.example.smartstock.ui.theme.ExtraBlue
import com.example.smartstock.ui.theme.LowConfidenceTintDark
import com.example.smartstock.ui.theme.LowConfidenceTintLight
import com.example.smartstock.ui.theme.MatchGreen
import com.example.smartstock.ui.theme.ShortageRed
import com.example.smartstock.ui.theme.WarningAmber

@Composable
fun CargoScreen(
    state: AppUiState,
    onAnalyze: (sentUri: Uri?, receivedUri: Uri) -> Unit,
    onCancelAnalyze: () -> Unit,
    onDismissError: () -> Unit,
    onUpdateQty: (String, Int) -> Unit,
    onRemoveItem: (String) -> Unit,
    onMapToExisting: (String, Item) -> Unit,
    onMarkAsNew: (String) -> Unit,
    onAddMissedItem: (String, Int) -> Unit,
    onConfirm: (onSuccess: () -> Unit) -> Unit,
    onBuildShareReport: () -> String,
    onShowMessage: (String) -> Unit
) {
    val context = LocalContext.current
    var sentUriStr by rememberSaveable { mutableStateOf<String?>(null) }
    var receivedUriStr by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingCameraUriStr by rememberSaveable { mutableStateOf<String?>(null) }
    var pendingCameraIsSent by rememberSaveable { mutableStateOf(false) }
    var showAddMissedDialog by remember { mutableStateOf(false) }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val captured = pendingCameraUriStr
        if (success && captured != null) {
            if (pendingCameraIsSent) sentUriStr = captured else receivedUriStr = captured
        }
        pendingCameraUriStr = null
    }

    val pickSentGallery = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) sentUriStr = uri.toString()
    }

    val pickReceivedGallery = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) receivedUriStr = uri.toString()
    }

    val cargo = state.cargo

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Photo Slot 1: Sent Cargo (Optional)
        item(key = "slot_sent") {
            CargoPhotoSlotCard(
                title = stringResource(R.string.cargo_sent_slot_title),
                uriStr = sentUriStr,
                onTakePhoto = {
                    val uri = ImageProcessor.createCameraPhotoUri(context)
                    pendingCameraUriStr = uri.toString()
                    pendingCameraIsSent = true
                    takePictureLauncher.launch(uri)
                },
                onPickGallery = {
                    pickSentGallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onRemove = { sentUriStr = null }
            )
        }

        // Photo Slot 2: Received Cargo (Required)
        item(key = "slot_received") {
            CargoPhotoSlotCard(
                title = stringResource(R.string.cargo_received_slot_title),
                uriStr = receivedUriStr,
                onTakePhoto = {
                    val uri = ImageProcessor.createCameraPhotoUri(context)
                    pendingCameraUriStr = uri.toString()
                    pendingCameraIsSent = false
                    takePictureLauncher.launch(uri)
                },
                onPickGallery = {
                    pickReceivedGallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onRemove = { receivedUriStr = null }
            )
        }

        // Analyze Button
        item(key = "cargo_analyze_btn") {
            Button(
                onClick = {
                    val rec = receivedUriStr
                    if (rec == null) {
                        onShowMessage(context.getString(R.string.cargo_err_need_received_photo))
                    } else {
                        onAnalyze(sentUriStr?.let(Uri::parse), Uri.parse(rec))
                    }
                },
                enabled = !cargo.isAnalyzing && receivedUriStr != null,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 52.dp)
            ) {
                Text(
                    text = stringResource(R.string.cargo_btn_analyze),
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }

        // Progress Card
        if (cargo.isAnalyzing) {
            item(key = "cargo_progress") {
                AiProgressCard(
                    percent = cargo.progressPercent,
                    statusText = cargo.progressStatus,
                    onCancel = onCancelAnalyze
                )
            }
        }

        // Error Banner
        cargo.errorMessage?.let { err ->
            item(key = "cargo_error") {
                ErrorBanner(message = err, onDismiss = onDismissError)
            }
        }

        // Empty State when no preview yet
        if (!cargo.isAnalyzing && cargo.receivedPreview.isEmpty()) {
            item(key = "cargo_empty") {
                EmptyStateCard(
                    title = stringResource(R.string.cargo_empty_title),
                    body = stringResource(R.string.cargo_empty_body)
                )
            }
            if (cargo.lastSavedReportAm.isNotBlank() || cargo.lastSavedShortages.isNotEmpty()) {
                item(key = "cargo_share_last") {
                    OutlinedButton(
                        onClick = {
                            val text = onBuildShareReport()
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, text)
                            }
                            context.startActivity(Intent.createChooser(intent, context.getString(R.string.cargo_btn_share_report)))
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.cargo_btn_share_report))
                    }
                }
            }
        }

        // Comparison Table (only when sent photo had items)
        val comparison = cargo.comparisonRows
        if (comparison.isNotEmpty()) {
            item(key = "cargo_comparison_table") {
                CargoComparisonTableCard(rows = comparison)
            }
        }

        // Gemini Amharic Report
        if (cargo.reportAm.isNotBlank() || cargo.photoNoteAm.isNotBlank()) {
            item(key = "cargo_report") {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = stringResource(R.string.cargo_ai_report_title),
                            style = MaterialTheme.typography.titleMedium
                        )
                        if (cargo.reportAm.isNotBlank()) {
                            Text(text = cargo.reportAm, style = MaterialTheme.typography.bodyMedium)
                        }
                        if (cargo.photoNoteAm.isNotBlank()) {
                            Text(
                                text = cargo.photoNoteAm,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Editable Received Preview
        if (cargo.receivedPreview.isNotEmpty()) {
            item(key = "cargo_preview_header") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.cargo_preview_title),
                        style = MaterialTheme.typography.titleMedium
                    )
                    TextButton(
                        onClick = { showAddMissedDialog = true },
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text(stringResource(R.string.cargo_btn_add_missed))
                    }
                }
            }

            items(cargo.receivedPreview, key = { it.tempId }) { row ->
                EditableCargoRowCard(
                    row = row,
                    catalogue = state.items,
                    onUpdateQty = { delta -> onUpdateQty(row.tempId, delta) },
                    onRemove = { onRemoveItem(row.tempId) },
                    onMapExisting = { existing -> onMapToExisting(row.tempId, existing) },
                    onMarkNew = { onMarkAsNew(row.tempId) }
                )
            }

            // Confirm & Share Buttons
            item(key = "cargo_confirm_actions") {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            onConfirm {
                                sentUriStr = null
                                receivedUriStr = null
                            }
                        },
                        enabled = !cargo.isSubmitting && cargo.receivedPreview.any { it.qty > 0 },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 54.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.cargo_btn_confirm),
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            val text = onBuildShareReport()
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, text)
                            }
                            context.startActivity(Intent.createChooser(intent, context.getString(R.string.cargo_btn_share_report)))
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(stringResource(R.string.cargo_btn_share_report))
                    }
                }
            }
        }
    }

    if (showAddMissedDialog) {
        AddMissedCargoItemDialog(
            onDismiss = { showAddMissedDialog = false },
            onAdd = { name, qty ->
                onAddMissedItem(name, qty)
                showAddMissedDialog = false
            }
        )
    }
}

@Composable
private fun CargoPhotoSlotCard(
    title: String,
    uriStr: String?,
    onTakePhoto: () -> Unit,
    onPickGallery: () -> Unit,
    onRemove: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium)
            if (uriStr != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    UriThumbnail(uri = Uri.parse(uriStr), size = 84.dp)
                    OutlinedButton(
                        onClick = onRemove,
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(R.string.action_remove))
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(
                    onClick = onTakePhoto,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                ) {
                    Text(stringResource(R.string.action_take_photo))
                }
                OutlinedButton(
                    onClick = onPickGallery,
                    modifier = Modifier
                        .weight(1f)
                        .heightIn(min = 48.dp)
                ) {
                    Text(stringResource(R.string.action_pick_gallery))
                }
            }
        }
    }
}

@Composable
private fun CargoComparisonTableCard(rows: List<CargoShortage>) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = stringResource(R.string.cargo_comparison_title),
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Text(stringResource(R.string.cargo_col_item), style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(2f))
                Text(stringResource(R.string.cargo_col_sent), style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                Text(stringResource(R.string.cargo_col_received), style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1f))
                Text(stringResource(R.string.cargo_col_diff), style = MaterialTheme.typography.labelLarge, modifier = Modifier.weight(1.4f))
            }
            rows.forEach { row ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(row.name, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(2f))
                    Text(row.sentQty.toString(), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    Text(row.receivedQty.toString(), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    val (diffText, diffColor) = when {
                        row.diff < 0 -> stringResource(R.string.cargo_diff_short, -row.diff) to ShortageRed
                        row.diff > 0 -> stringResource(R.string.cargo_diff_extra, row.diff) to ExtraBlue
                        else -> stringResource(R.string.cargo_diff_ok) to MatchGreen
                    }
                    Text(
                        text = diffText,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = diffColor,
                        modifier = Modifier.weight(1.4f)
                    )
                }
            }
        }
    }
}

@Composable
private fun EditableCargoRowCard(
    row: EditableCargoItem,
    catalogue: List<Item>,
    onUpdateQty: (Int) -> Unit,
    onRemove: () -> Unit,
    onMapExisting: (Item) -> Unit,
    onMarkNew: () -> Unit
) {
    val isDark = isSystemInDarkTheme()
    val isLowConf = row.confidence == Confidence.LOW
    val cardBg = if (isLowConf) {
        if (isDark) LowConfidenceTintDark else LowConfidenceTintLight
    } else {
        MaterialTheme.colorScheme.surface
    }
    var mapExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = row.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        ConfidenceChip(confidence = row.confidence)
                        if (isLowConf) {
                            StatusBadge(
                                text = stringResource(R.string.cargo_verify_badge),
                                backgroundColor = WarningAmber,
                                contentColor = Color.White
                            )
                        }
                        if (row.matchedItemId == null) {
                            StatusBadge(
                                text = stringResource(R.string.cargo_new_item_chip),
                                backgroundColor = MaterialTheme.colorScheme.secondaryContainer,
                                contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(
                        onClick = { onUpdateQty(-1) },
                        enabled = row.qty > 0,
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(48.dp)
                    ) {
                        Text("−", style = MaterialTheme.typography.titleLarge)
                    }
                    Text(
                        text = row.qty.toString(),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                    OutlinedButton(
                        onClick = { onUpdateQty(1) },
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(48.dp)
                    ) {
                        Text("+", style = MaterialTheme.typography.titleLarge)
                    }
                    IconButton(onClick = onRemove, modifier = Modifier.size(48.dp)) {
                        Icon(
                            Icons.Default.Delete,
                            contentDescription = stringResource(R.string.action_remove),
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }

            // Map to existing dropdown when unmatched or allow remapping
            if (catalogue.isNotEmpty() && row.matchedItemId == null) {
                Box {
                    OutlinedButton(
                        onClick = { mapExpanded = true },
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text(stringResource(R.string.cargo_map_existing))
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
                    }
                    DropdownMenu(expanded = mapExpanded, onDismissRequest = { mapExpanded = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.cargo_create_new_option)) },
                            onClick = {
                                onMarkNew()
                                mapExpanded = false
                            }
                        )
                        catalogue.forEach { item ->
                            DropdownMenuItem(
                                text = { Text("${item.name} (${item.qty} ${item.unit})") },
                                onClick = {
                                    onMapExisting(item)
                                    mapExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddMissedCargoItemDialog(
    onDismiss: () -> Unit,
    onAdd: (String, Int) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var qtyText by remember { mutableStateOf("1") }
    var nameError by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.cargo_btn_add_missed)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        nameError = false
                    },
                    label = { Text(stringResource(R.string.stock_field_name)) },
                    isError = nameError,
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = qtyText,
                    onValueChange = { qtyText = it.filter { ch -> ch.isDigit() } },
                    label = { Text(stringResource(R.string.stock_field_qty)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val trimmed = name.trim()
                if (trimmed.isEmpty()) {
                    nameError = true
                } else {
                    onAdd(trimmed, qtyText.toIntOrNull()?.coerceAtLeast(1) ?: 1)
                }
            }) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(stringResource(R.string.action_add))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.action_cancel))
            }
        }
    )
}
