package com.example.smartstock.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.URLEncoder

/**
 * Resolves the best available Gemini Flash model on 404 by listing /v1beta/models?pageSize=100
 * and following nextPageToken.
 */
class ModelResolver(private val client: OkHttpClient) {

    suspend fun resolveBestFlashModel(apiKey: String): String = withContext(Dispatchers.IO) {
        val collected = mutableListOf<JSONObject>()
        var pageToken: String? = null
        var pagesFetched = 0

        do {
            val urlBuilder = StringBuilder("https://generativelanguage.googleapis.com/v1beta/models?pageSize=100")
            if (!pageToken.isNullOrBlank()) {
                urlBuilder.append("&pageToken=").append(URLEncoder.encode(pageToken, "UTF-8"))
            }
            val request = Request.Builder()
                .url(urlBuilder.toString())
                .header("x-goog-api-key", apiKey)
                .get()
                .build()

            val response = try {
                client.newCall(request).execute()
            } catch (_: SocketTimeoutException) {
                throw AiException(AiErrorType.TIMEOUT)
            } catch (_: IOException) {
                throw AiException(AiErrorType.NO_INTERNET)
            }

            response.use { resp ->
                when (resp.code) {
                    401, 403 -> throw AiException(AiErrorType.INVALID_KEY)
                    400 -> throw AiException(AiErrorType.BAD_REQUEST)
                    in 200..299 -> {
                        val body = resp.body?.string().orEmpty()
                        val root = try {
                            JSONObject(body)
                        } catch (_: Exception) {
                            throw AiException(AiErrorType.PARSE_FAILED)
                        }
                        val arr = root.optJSONArray("models")
                        if (arr != null) {
                            for (i in 0 until arr.length()) {
                                val obj = arr.optJSONObject(i) ?: continue
                                collected.add(obj)
                            }
                        }
                        pageToken = root.optString("nextPageToken", "").takeIf { it.isNotBlank() }
                    }
                    else -> throw AiException(AiErrorType.NO_MODEL_FOUND)
                }
            }
            pagesFetched++
        } while (!pageToken.isNullOrBlank() && pagesFetched < 10)

        ResponseParsers.selectBestFlashModel(collected)
            ?: throw AiException(AiErrorType.NO_MODEL_FOUND)
    }
}
