package com.example.smartstock.util

import com.example.smartstock.data.Item
import java.util.Locale

object NameNormalizer {

    private val geezDigitMap: Map<Char, Int> = mapOf(
        '፩' to 1,
        '፪' to 2,
        '፫' to 3,
        '፬' to 4,
        '፭' to 5,
        '፮' to 6,
        '፯' to 7,
        '፰' to 8,
        '፱' to 9,
        '፲' to 10,
        '፳' to 20,
        '፴' to 30,
        '፵' to 40,
        '፶' to 50,
        '፷' to 60,
        '፸' to 70,
        '፹' to 80,
        '፺' to 90,
        '፻' to 100
    )

    /**
     * Normalizes an item name for matching:
     * 1. Convert Ge'ez numerals (፩–፱, ፲, tens, ፻) to ASCII digits
     * 2. Lowercase
     * 3. Strip punctuation (keeping letters, Ethiopic syllables, digits, and whitespace)
     * 4. Collapse consecutive whitespace and trim
     */
    fun normalize(raw: String): String {
        if (raw.isBlank()) return ""
        val withDigits = convertGeezNumerals(raw)
        val lowered = withDigits.lowercase(Locale.ROOT)
        val cleaned = StringBuilder(lowered.length)
        for (ch in lowered) {
            when {
                ch.isLetterOrDigit() -> cleaned.append(ch)
                ch.isWhitespace() -> cleaned.append(' ')
                // Strip punctuation (including Ethiopic punctuation ፡ ። ፣ ፤ ፥ ፦ ፧ ፨)
                else -> cleaned.append(' ')
            }
        }
        return cleaned.toString()
            .trim()
            .replace(Regex("\\s+"), " ")
    }

    fun convertGeezNumerals(input: String): String {
        val out = StringBuilder(input.length)
        var i = 0
        while (i < input.length) {
            val ch = input[i]
            if (geezDigitMap.containsKey(ch)) {
                var total = 0
                var current = 0
                while (i < input.length && geezDigitMap.containsKey(input[i])) {
                    val v = geezDigitMap[input[i]] ?: 0
                    if (v == 100) {
                        val mult = if (current == 0) 1 else current
                        total += mult * 100
                        current = 0
                    } else {
                        current += v
                    }
                    i++
                }
                total += current
                out.append(total.toString())
            } else {
                out.append(ch)
                i++
            }
        }
        return out.toString()
    }

    /**
     * Match order:
     * 1. Exact normalised name or alias in catalogue
     * 2. Gemini's matchedStockId if it exists in the catalogue
     * 3. Null (unmatched)
     */
    fun matchItem(
        rawName: String,
        matchedStockId: String?,
        catalogue: List<Item>
    ): Item? {
        val norm = normalize(rawName)
        if (norm.isNotEmpty()) {
            val byName = catalogue.firstOrNull { normalize(it.name) == norm }
            if (byName != null) return byName

            val byAlias = catalogue.firstOrNull { item ->
                item.aliases.any { alias -> normalize(alias) == norm }
            }
            if (byAlias != null) return byAlias
        }
        if (!matchedStockId.isNullOrBlank()) {
            return catalogue.firstOrNull { it.id == matchedStockId }
        }
        return null
    }
}
