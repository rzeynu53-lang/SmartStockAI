package com.example.smartstock.data

import java.util.UUID

enum class TxnType {
    STOCK_IN,
    SALE
}

enum class TxnStatus {
    ACTIVE,
    VOIDED
}

enum class DateStyle {
    ETHIOPIAN,
    GREGORIAN
}

enum class Confidence {
    HIGH,
    MEDIUM,
    LOW;

    companion object {
        fun fromApi(raw: String?): Confidence {
            return when (raw?.trim()?.lowercase()) {
                "high" -> HIGH
                "medium" -> MEDIUM
                else -> LOW
            }
        }
    }
}

data class Item(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val unit: String = DEFAULT_UNIT,
    val qty: Int = 0,
    val lowThreshold: Int = DEFAULT_LOW_THRESHOLD,
    val sellPrice: Double? = null,
    val costPrice: Double? = null,
    val aliases: List<String> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val DEFAULT_UNIT = "ፍሬ"
        const val DEFAULT_LOW_THRESHOLD = 3
        val AVAILABLE_UNITS = listOf("ፍሬ", "ካርቶን", "ኪሎ", "ሊትር", "ጥቅል")
    }
}

data class Line(
    val itemId: String?,
    val name: String,
    val qty: Int,
    val unitPrice: Double? = null
)

data class CargoShortage(
    val name: String,
    val sentQty: Int,
    val receivedQty: Int,
    val diff: Int // receivedQty - sentQty (<0 shortage, >0 extra, 0 ok)
)

data class Txn(
    val id: String = UUID.randomUUID().toString(),
    val type: TxnType,
    val timestamp: Long = System.currentTimeMillis(),
    val lines: List<Line>,
    val totalEtb: Double = 0.0,
    val shortages: List<CargoShortage> = emptyList(),
    val reportAm: String? = null,
    val photoFiles: List<String> = emptyList(),
    val imageHashes: List<String> = emptyList(),
    val status: TxnStatus = TxnStatus.ACTIVE,
    val voidedAt: Long? = null,
    val note: String? = null
)

data class AppSettings(
    val activeModel: String = DEFAULT_MODEL,
    val defaultLowThreshold: Int = Item.DEFAULT_LOW_THRESHOLD,
    val dateStyle: DateStyle = DateStyle.ETHIOPIAN,
    val privacyAccepted: Boolean = false,
    val cachedAdviceDate: String? = null,
    val cachedAdviceLines: List<String> = emptyList()
) {
    companion object {
        const val DEFAULT_MODEL = "gemini-3.8-flash"
    }
}

data class BackupPayload(
    val schemaVersion: Int,
    val exportedAt: Long,
    val items: List<Item>,
    val settings: AppSettings,
    val history: List<Txn>
)

// AI parsed models
data class CargoSentItem(
    val name: String,
    val qty: Int,
    val confidence: Confidence
)

data class CargoReceivedItem(
    val name: String,
    val matchedStockId: String?,
    val qty: Int,
    val confidence: Confidence
)

data class CargoAnalysisResult(
    val sentItems: List<CargoSentItem>,
    val receivedItems: List<CargoReceivedItem>,
    val reportAm: String,
    val photoNoteAm: String
)

data class SalesParsedLine(
    val rawText: String,
    val name: String,
    val matchedStockId: String?,
    val qty: Int,
    val unitPrice: Double?,
    val lineTotal: Double?,
    val confidence: Confidence
)

data class SalesAnalysisResult(
    val lines: List<SalesParsedLine>,
    val writtenGrandTotal: Double?,
    val notesAm: String
)
