package com.example.smartstock.ai

import com.example.smartstock.data.Item
import org.json.JSONArray
import org.json.JSONObject

object GeminiPrompts {

    private const val MAX_CATALOGUE_ITEMS = 300

    fun buildCatalogueJson(items: List<Item>): String {
        val arr = JSONArray()
        items.take(MAX_CATALOGUE_ITEMS).forEach { item ->
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("name", item.name)
            obj.put("unit", item.unit)
            if (item.aliases.isNotEmpty()) {
                val aliases = JSONArray()
                item.aliases.forEach { aliases.put(it) }
                obj.put("aliases", aliases)
            }
            arr.put(obj)
        }
        return arr.toString()
    }

    fun cargoSystemInstruction(): String = """
        You are an inventory assistant for an Ethiopian shop.
        Count ONLY clearly visible units in the provided cargo photos. NEVER guess hidden or obstructed items; if items might be hidden or stacked behind others, state that explicitly in report_am.
        Match received items against the provided shop catalogue JSON (id, name, aliases, unit) and put the exact matching catalogue id in matched_stock_id, or null if unmatched.
        If only one photo (received cargo) is provided, sent_items MUST be an empty array [].
        If two photos are provided, image 1 is SENT cargo and image 2 is RECEIVED cargo.
        Set confidence to "high", "medium", or "low". Mark blurry, ambiguous, or partially obscured items as "low".
        ALL free text (report_am, photo_note_am, and item names when not in English) MUST be written in natural Amharic (አማርኛ).
        Return strictly valid JSON matching the requested schema.
    """.trimIndent()

    fun cargoUserPrompt(items: List<Item>, hasSentPhoto: Boolean): String {
        val catalogue = buildCatalogueJson(items)
        val photoDesc = if (hasSentPhoto) {
            "Photo 1 is the SENT cargo. Photo 2 is the RECEIVED cargo."
        } else {
            "Only the RECEIVED cargo photo is provided (count mode; return sent_items as [])."
        }
        return "$photoDesc\nShop catalogue JSON:\n$catalogue"
    }

    fun cargoResponseSchema(): JSONObject {
        val sentItemProps = JSONObject()
            .put("name", JSONObject().put("type", "STRING"))
            .put("qty", JSONObject().put("type", "INTEGER"))
            .put("confidence", JSONObject().put("type", "STRING").put("enum", JSONArray(listOf("high", "medium", "low"))))

        val receivedItemProps = JSONObject()
            .put("name", JSONObject().put("type", "STRING"))
            .put("matched_stock_id", JSONObject().put("type", "STRING").put("nullable", true))
            .put("qty", JSONObject().put("type", "INTEGER"))
            .put("confidence", JSONObject().put("type", "STRING").put("enum", JSONArray(listOf("high", "medium", "low"))))

        return JSONObject()
            .put("type", "OBJECT")
            .put(
                "properties",
                JSONObject()
                    .put(
                        "sent_items",
                        JSONObject()
                            .put("type", "ARRAY")
                            .put(
                                "items",
                                JSONObject()
                                    .put("type", "OBJECT")
                                    .put("properties", sentItemProps)
                                    .put("required", JSONArray(listOf("name", "qty", "confidence")))
                            )
                    )
                    .put(
                        "received_items",
                        JSONObject()
                            .put("type", "ARRAY")
                            .put(
                                "items",
                                JSONObject()
                                    .put("type", "OBJECT")
                                    .put("properties", receivedItemProps)
                                    .put("required", JSONArray(listOf("name", "qty", "confidence")))
                            )
                    )
                    .put("report_am", JSONObject().put("type", "STRING"))
                    .put("photo_note_am", JSONObject().put("type", "STRING"))
            )
            .put("required", JSONArray(listOf("sent_items", "received_items", "report_am", "photo_note_am")))
    }

    fun salesSystemInstruction(): String = """
        You are reading handwritten sales-notebook pages from a small Ethiopian shop.
        Handwriting mixes Amharic (አማርኛ), English, and Ge'ez numerals (፩–፱, ፲, etc.).
        CRITICAL PARSING RULES:
        - In expressions like "2 x 1550 = 3100", qty is 2, unit_price is 1550, and line_total is 3100.
        - qty is ALWAYS the count sold, NEVER the price.
        - If the order of quantity and price is ambiguous, use the written line_total to decide which number is qty and which is unit_price.
        - Ignore struck-through/crossed-out lines, dates, customer names, phone numbers, and page headings.
        - NEVER invent items that are not written on the page.
        - Mark any doubtful, smudged, or hard-to-read line with confidence "low".
        - Match each item to the provided shop catalogue JSON (id, name, aliases, unit) and return its exact id in matched_stock_id, or null if not matched.
        - If a grand total is written at the bottom of the page, extract it as written_grand_total (otherwise null).
        - Write notes_am in natural Amharic.
        Return strictly valid JSON matching the requested schema.
    """.trimIndent()

    fun salesUserPrompt(items: List<Item>, photoCount: Int): String {
        val catalogue = buildCatalogueJson(items)
        return "Read all $photoCount handwritten sales-notebook page photo(s) and extract every valid sales line.\nShop catalogue JSON:\n$catalogue"
    }

    fun salesResponseSchema(): JSONObject {
        val lineProps = JSONObject()
            .put("raw_text", JSONObject().put("type", "STRING"))
            .put("name", JSONObject().put("type", "STRING"))
            .put("matched_stock_id", JSONObject().put("type", "STRING").put("nullable", true))
            .put("qty", JSONObject().put("type", "INTEGER"))
            .put("unit_price", JSONObject().put("type", "NUMBER").put("nullable", true))
            .put("line_total", JSONObject().put("type", "NUMBER").put("nullable", true))
            .put("confidence", JSONObject().put("type", "STRING").put("enum", JSONArray(listOf("high", "medium", "low"))))

        return JSONObject()
            .put("type", "OBJECT")
            .put(
                "properties",
                JSONObject()
                    .put(
                        "lines",
                        JSONObject()
                            .put("type", "ARRAY")
                            .put(
                                "items",
                                JSONObject()
                                    .put("type", "OBJECT")
                                    .put("properties", lineProps)
                                    .put("required", JSONArray(listOf("raw_text", "name", "qty", "confidence")))
                            )
                    )
                    .put("written_grand_total", JSONObject().put("type", "NUMBER").put("nullable", true))
                    .put("notes_am", JSONObject().put("type", "STRING"))
            )
            .put("required", JSONArray(listOf("lines", "notes_am")))
    }

    fun weeklyAdviceSystemInstruction(): String = """
        You are a practical business advisor for a small Ethiopian shop owner.
        Based ONLY on the compact 14-day sales, stock, and days-of-cover summary provided, give 3 to 5 short, actionable suggestions in natural Amharic (አማርኛ).
        Focus on: items to reorder soon (low days of cover), slow movers, and any sales or stock anomalies.
        Keep each suggestion concise (1–2 sentences). Return strictly valid JSON matching the schema.
    """.trimIndent()

    fun weeklyAdviceResponseSchema(): JSONObject {
        return JSONObject()
            .put("type", "OBJECT")
            .put(
                "properties",
                JSONObject().put(
                    "suggestions",
                    JSONObject()
                        .put("type", "ARRAY")
                        .put("items", JSONObject().put("type", "STRING"))
                )
            )
            .put("required", JSONArray(listOf("suggestions")))
    }
}
