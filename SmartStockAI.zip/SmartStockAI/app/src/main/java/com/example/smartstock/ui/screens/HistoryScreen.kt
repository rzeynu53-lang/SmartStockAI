package com.example.smartstock.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.smartstock.R
import com.example.smartstock.data.DateStyle
import com.example.smartstock.data.Txn
import com.example.smartstock.data.TxnStatus
import com.example.smartstock.data.TxnType
import com.example.smartstock.ui.AppUiState
import com.example.smartstock.ui.components.EmptyStateCard
import com.example.smartstock.ui.components.FileThumbnail
import com.example.smartstock.ui.components.StatusBadge
import com.example.smartstock.ui.theme.ShortageRed
import com.example.smartstock.util.EthiopianCalendar
import com.example.smartstock.util.Formatters
import java.io.File
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

private enum class HistoryFilter {
    ALL,
    CARGO,
    SALES
}

@Composable
fun HistoryScreen(
    state: AppUiState,
    evidenceFileProvider: (String) -> File,
    onVoidTxn: (String) -> Unit,
    onExportCsv: (Uri) -> Unit
) {
    var filter by rememberSaveable { mutableStateOf(HistoryFilter.ALL) }
    var voidCandidate by remember { mutableStateOf<Txn?>(null) }
    var previewPhotoFile by remember { mutableStateOf<File?>(null) }

    val csvLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        if (uri != null) onExportCsv(uri)
    }

    val useEth = state.settings.dateStyle == DateStyle.ETHIOPIAN
    val filtered = remember(state.history, filter) {
        state.history.filter { txn ->
            when (filter) {
                HistoryFilter.ALL -> true
                HistoryFilter.CARGO -> txn.type == TxnType.STOCK_IN
                HistoryFilter.SALES -> txn.type == TxnType.SALE
            }
        }
    }

    val groupedByDay: List<Pair<LocalDate, List<Txn>>> = remember(filtered) {
        val zone = ZoneId.systemDefault()
        filtered
            .groupBy { Instant.ofEpochMilli(it.timestamp).atZone(zone).toLocalDate() }
            .entries
            .sortedByDescending { it.key }
            .map { it.key to it.value.sortedByDescending { t -> t.timestamp } }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "history_controls") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(
                        selected = filter == HistoryFilter.ALL,
                        onClick = { filter = HistoryFilter.ALL },
                        label = { Text(stringResource(R.string.history_filter_all)) }
                    )
                    FilterChip(
                        selected = filter == HistoryFilter.CARGO,
                        onClick = { filter = HistoryFilter.CARGO },
                        label = { Text(stringResource(R.string.history_filter_cargo)) }
                    )
                    FilterChip(
                        selected = filter == HistoryFilter.SALES,
                        onClick = { filter = HistoryFilter.SALES },
                        label = { Text(stringResource(R.string.history_filter_sales)) }
                    )
                }
                OutlinedButton(
                    onClick = { csvLauncher.launch("smartstock_history.csv") },
                    enabled = state.history.isNotEmpty(),
                    modifier = Modifier.heightIn(min = 48.dp)
                ) {
                    Text(stringResource(R.string.history_btn_export_csv))
                }
            }
        }

        if (groupedByDay.isEmpty()) {
            item(key = "history_empty") {
                EmptyStateCard(
                    title = stringResource(R.string.history_empty_title),
                    body = stringResource(R.string.history_empty_body)
                )
            }
        } else {
            groupedByDay.forEach { (date, txns) ->
                val daySalesTotal = txns
                    .filter { it.status == TxnStatus.ACTIVE && it.type == TxnType.SALE }
                    .sumOf { it.totalEtb }

                item(key = "header_$date") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = EthiopianCalendar.formatDate(date, useEth),
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        if (daySalesTotal > 0.0) {
                            Text(
                                text = stringResource(
                                    R.string.history_day_sales_total,
                                    Formatters.formatMoney(daySalesTotal)
                                ),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                items(txns, key = { it.id }) { txn ->
                    HistoryTxnCard(
                        txn = txn,
                        evidenceFileProvider = evidenceFileProvider,
                        onPhotoClick = { previewPhotoFile = it },
                        onVoidClick = { voidCandidate = txn }
                    )
                }
            }
        }
    }

    voidCandidate?.let { target ->
        AlertDialog(
            onDismissRequest = { voidCandidate = null },
            title = { Text(stringResource(R.string.history_void_title)) },
            text = { Text(stringResource(R.string.history_void_body)) },
            confirmButton = {
                Button(onClick = {
                    onVoidTxn(target.id)
                    voidCandidate = null
                }) {
                    Text(stringResource(R.string.history_btn_void))
                }
            },
            dismissButton = {
                TextButton(onClick = { voidCandidate = null }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }

    previewPhotoFile?.let { photo ->
        AlertDialog(
            onDismissRequest = { previewPhotoFile = null },
            title = { Text(stringResource(R.string.history_photo_preview)) },
            text = {
                FileThumbnail(file = photo, size = 260.dp)
            },
            confirmButton = {
                TextButton(onClick = { previewPhotoFile = null }) {
                    Text(stringResource(R.string.action_close))
                }
            }
        )
    }
}

@Composable
private fun HistoryTxnCard(
    txn: Txn,
    evidenceFileProvider: (String) -> File,
    onPhotoClick: (File) -> Unit,
    onVoidClick: () -> Unit
) {
    val isVoided = txn.status == TxnStatus.VOIDED
    val decoration = if (isVoided) TextDecoration.LineThrough else TextDecoration.None
    val shortageCount = txn.shortages.count { it.diff < 0 }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isVoided) {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
            } else {
                MaterialTheme.colorScheme.surface
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(
                            if (txn.type == TxnType.SALE) R.string.history_type_sale else R.string.history_type_stock_in
                        ),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        textDecoration = decoration
                    )
                    Text(
                        text = EthiopianCalendar.formatTimestampTime(txn.timestamp),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (isVoided) {
                        StatusBadge(
                            text = stringResource(R.string.history_voided_badge),
                            backgroundColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        )
                    } else if (txn.type == TxnType.STOCK_IN && shortageCount > 0) {
                        StatusBadge(
                            text = stringResource(R.string.history_shortage_badge, shortageCount),
                            backgroundColor = ShortageRed.copy(alpha = 0.16f),
                            contentColor = ShortageRed
                        )
                    }
                }

                if (txn.type == TxnType.SALE) {
                    Text(
                        text = stringResource(R.string.money_format, Formatters.formatMoney(txn.totalEtb)),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textDecoration = decoration
                    )
                }
            }

            // Itemised lines
            txn.lines.forEach { line ->
                val pricePart = line.unitPrice?.let {
                    " × ${stringResource(R.string.money_format, Formatters.formatMoney(it))}"
                }.orEmpty()
                Text(
                    text = "• ${line.name} — ${line.qty}$pricePart",
                    style = MaterialTheme.typography.bodyMedium,
                    textDecoration = decoration
                )
            }

            txn.note?.let { note ->
                Text(
                    text = note,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Tappable thumbnails
            if (txn.photoFiles.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(txn.photoFiles, key = { it }) { fileName ->
                        val file = evidenceFileProvider(fileName)
                        FileThumbnail(
                            file = file,
                            size = 64.dp,
                            onClick = { onPhotoClick(file) }
                        )
                    }
                }
            }

            if (!isVoided) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                        onClick = onVoidClick,
                        modifier = Modifier.heightIn(min = 48.dp)
                    ) {
                        Text(
                            text = stringResource(R.string.history_btn_void),
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                }
            }
        }
    }
}
