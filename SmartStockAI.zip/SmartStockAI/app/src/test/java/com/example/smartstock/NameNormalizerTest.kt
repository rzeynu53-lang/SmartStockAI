package com.example.smartstock

import com.example.smartstock.data.Item
import com.example.smartstock.util.NameNormalizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class NameNormalizerTest {

    @Test
    fun normalize_trimsLowercasesCollapsesSpacesAndStripsPunctuation() {
        assertEquals("sugar 1 kg", NameNormalizer.normalize("  Sugar,  1-KG!!  "))
        assertEquals("ዘይት 5 ሊትር", NameNormalizer.normalize("  ዘይት፡ ፭  ሊትር። "))
    }

    @Test
    fun convertGeezNumerals_handlesSingleAndCompoundNumbers() {
        assertEquals("1", NameNormalizer.convertGeezNumerals("፩"))
        assertEquals("9", NameNormalizer.convertGeezNumerals("፱"))
        assertEquals("10", NameNormalizer.convertGeezNumerals("፲"))
        assertEquals("15", NameNormalizer.convertGeezNumerals("፲፭"))
        assertEquals("ሳሙና 25 ፍሬ", NameNormalizer.convertGeezNumerals("ሳሙና ፳፭ ፍሬ"))
    }

    @Test
    fun matchItem_prefersNormalizedNameThenAliasThenGeminiId() {
        val sugar = Item(id = "id-sugar", name = "ስኳር 1 ኪሎ", aliases = listOf("sugar 1kg", "ስኳር ፩ ኪሎ"))
        val oil = Item(id = "id-oil", name = "ዘይት 5 ሊትር", aliases = listOf("oil 5L"))
        val catalogue = listOf(sugar, oil)

        // Exact normalized name
        assertEquals(sugar, NameNormalizer.matchItem("ስኳር ፩ ኪሎ!", null, catalogue))
        // Exact alias
        assertEquals(oil, NameNormalizer.matchItem("  OIL 5L  ", null, catalogue))
        // Fallback to Gemini's matched_stock_id
        assertEquals(oil, NameNormalizer.matchItem("የምግብ ዘይት", "id-oil", catalogue))
        // Unknown id & unmatched name -> null
        assertNull(NameNormalizer.matchItem("አዲስ እቃ", "non-existent", catalogue))
    }
}
