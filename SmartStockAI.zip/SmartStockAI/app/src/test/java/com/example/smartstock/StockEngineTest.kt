package com.example.smartstock

import com.example.smartstock.data.Confidence
import com.example.smartstock.data.Item
import com.example.smartstock.data.Line
import com.example.smartstock.data.Txn
import com.example.smartstock.data.TxnStatus
import com.example.smartstock.data.TxnType
import com.example.smartstock.domain.EditableSaleLine
import com.example.smartstock.domain.SalesLineAction
import com.example.smartstock.domain.StockEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class StockEngineTest {

    @Test
    fun computeCargoDiff_calculatesShortageExtraAndExactMatch() {
        val sent = listOf("ዘይት" to 10, "ስኳር" to 5, "ሩዝ" to 4)
        val received = listOf("ዘይት" to 8, "ስኳር" to 5, "ሩዝ" to 6)

        val rows = StockEngine.computeCargoDiff(sent, received)
        assertEquals(3, rows.size)
        assertEquals(-2, rows[0].diff) // shortage
        assertEquals(0, rows[1].diff)  // exact
        assertEquals(2, rows[2].diff)  // extra
    }

    @Test
    fun computeCargoDiff_returnsEmptyInCountMode() {
        val rows = StockEngine.computeCargoDiff(emptyList(), listOf("ዘይት" to 5))
        assertTrue(rows.isEmpty())
    }

    @Test
    fun salesTotalsAndWarnings_detectsAllFourWarningConditions() {
        val oil = Item(id = "oil", name = "ዘይት", qty = 3, sellPrice = 1000.0, costPrice = 850.0)
        val line = EditableSaleLine(
            tempId = "t1",
            rawText = "5 x 1300 = 6000",
            rawName = "ዘይት",
            displayName = "ዘይት",
            qty = 5, // above stock (3)
            unitPrice = 1300.0, // 30% above 1000.0
            writtenLineTotal = 6000.0, // != 5 * 1300 (6500)
            confidence = Confidence.MEDIUM,
            matchedItemId = "oil",
            action = SalesLineAction.MATCHED
        )

        val total = StockEngine.computeSalesTotal(listOf(line))
        assertEquals(6500.0, total, 0.01)

        val warnings = StockEngine.computeSaleLineWarnings(line, listOf(oil))
        assertEquals(3, warnings.aboveStockRemaining)
        assertEquals(1000.0, warnings.cataloguePriceForDiffWarning!!, 0.01)
        assertNotNull(warnings.lineMathMismatch)
        assertEquals(6500.0, warnings.lineMathMismatch!!.first, 0.01)
        assertEquals(6000.0, warnings.lineMathMismatch!!.second, 0.01)

        assertTrue(StockEngine.hasGrandTotalMismatch(total, 6000.0))
        assertFalse(StockEngine.hasGrandTotalMismatch(total, 6500.0))
    }

    @Test
    fun applySaleAndVoid_neverNegativeAndVoidRestoresStock() {
        val item = Item(id = "i1", name = "ሳሙና", qty = 4, sellPrice = 100.0)
        val saleLines = listOf(Line(itemId = "i1", name = "ሳሙና", qty = 6, unitPrice = 100.0))

        val applyResult = StockEngine.applySale(listOf(item), saleLines)
        assertTrue(applyResult.stockClamped)
        assertEquals(0, applyResult.updatedItems.first().qty)

        val txn = Txn(
            id = "txn1",
            type = TxnType.SALE,
            lines = saleLines,
            totalEtb = 600.0,
            status = TxnStatus.ACTIVE
        )
        val afterVoid = StockEngine.reverseTxnStockEffect(applyResult.updatedItems, txn)
        assertEquals(6, afterVoid.first().qty)
    }

    @Test
    fun applyStockIn_learnsAliasAndVoidClampsAtZero() {
        val item = Item(id = "i1", name = "ዘይት 5 ሊትር", qty = 2)
        val lines = listOf(Line(itemId = "i1", name = "ዘይት 5 ሊትር", qty = 5))

        val afterIn = StockEngine.applyStockIn(
            currentItems = listOf(item),
            lines = lines,
            learnedAliases = mapOf("i1" to "የምግብ ዘይት 5L")
        )
        assertEquals(7, afterIn.first().qty)
        assertTrue(afterIn.first().aliases.contains("የምግብ ዘይት 5L"))

        // If stock dropped to 3 and we void the +5 stock-in, it clamps to 0
        val reduced = listOf(afterIn.first().copy(qty = 3))
        val txn = Txn(id = "t-in", type = TxnType.STOCK_IN, lines = lines, status = TxnStatus.ACTIVE)
        val afterVoid = StockEngine.reverseTxnStockEffect(reduced, txn)
        assertEquals(0, afterVoid.first().qty)
    }

    @Test
    fun canConfirmSale_blocksWhenUnresolvedLinesExist() {
        val unresolved = EditableSaleLine(
            tempId = "1", rawText = "x", rawName = "x", displayName = "x",
            qty = 1, unitPrice = 100.0, writtenLineTotal = 100.0,
            confidence = Confidence.HIGH, matchedItemId = null,
            action = SalesLineAction.UNRESOLVED
        )
        assertFalse(StockEngine.canConfirmSale(listOf(unresolved)))
        assertTrue(StockEngine.canConfirmSale(listOf(unresolved.copy(action = SalesLineAction.CREATE_NEW))))
    }

    @Test
    fun duplicatePhotoGuard_ignoresVoidedTransactions() {
        val activeTxn = Txn(type = TxnType.SALE, lines = emptyList(), imageHashes = listOf("abc123"), status = TxnStatus.ACTIVE)
        val voidedTxn = Txn(type = TxnType.SALE, lines = emptyList(), imageHashes = listOf("def456"), status = TxnStatus.VOIDED)

        assertTrue(StockEngine.isDuplicatePhoto(listOf("abc123"), listOf(activeTxn, voidedTxn)))
        assertFalse(StockEngine.isDuplicatePhoto(listOf("def456"), listOf(activeTxn, voidedTxn)))
    }

    @Test
    fun buildHistoryCsv_startsWithUtf8Bom() {
        val txn = Txn(
            type = TxnType.SALE,
            lines = listOf(Line("1", "ስኳር", 2, 150.0)),
            totalEtb = 300.0
        )
        val csv = StockEngine.buildHistoryCsv(listOf(txn), useEthiopianDate = true)
        assertTrue(csv.startsWith("\uFEFF"))
        assertTrue(csv.contains("ስኳር x2"))
    }
}
